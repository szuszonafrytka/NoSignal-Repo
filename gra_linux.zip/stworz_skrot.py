import os
import sys

def stworz_skrot_pulpit():
    # Pobieramy ścieżkę domową użytkownika (np. /home/fabian)
    home = os.path.expanduser("~")
    pulpit_path = os.path.join(home, "Pulpit")
    
    # Definiujemy ścieżkę do naszej gry i folderu
    gra_folder = os.path.join(pulpit_path, "MojaGra")
    gra_skrypt = os.path.join(gra_folder, "gra.py")
    
    # Nazwa pliku skrótu na pulpicie
    skrot_plik = os.path.join(pulpit_path, "NoSignal.desktop")
    
    # Zawartość pliku skrótu Linuxa
    content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name=No Signal Horror
Comment=Uruchom moja gre multiplayer
Exec=python3 {gra_skrypt}
Path={gra_folder}
Icon=controller
Terminal=false
Categories=Game;
"""
    
    try:
        # Zapisujemy plik skrótu na Pulpicie
        with open(skrot_plik, "w", encoding="utf-8") as f:
            f.write(content)
            
        # Nadajemy plikowi uprawnienia do uruchamiania (chmod +x)
        os.chmod(skrot_plik, 0o755)
        
        print("✅ Skrót został pomyślnie utworzony na Pulpicie!")
        print("💡 WAŻNE: Kliknij teraz na nową ikonę prawym przyciskiem myszy i wybierz 'Allow Launching' (Zezwól na uruchamianie).")
        
    except Exception as e:
        print(f"❌ Wystąpił błąd podczas tworzenia skrótu: {e}")

if __name__ == "__main__":
    stworz_skrot_pulpit()
