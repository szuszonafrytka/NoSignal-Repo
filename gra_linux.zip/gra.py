"""
main.py - No Signal: 3D Horror Game [STABLE BUILD & FIXED DARKNESS]
Zaimplementowano:
1. Pełne zabezpieczenie przed losowym wywalaniem gry (zabezpieczone losowanie pozycji i pop()).
2. Twarde, matematyczne odcięcie widzenia po zgaszeniu latarki (czarna próżnia poza 2 klockami).
3. Kompletny skrypt gotowy do uruchomienia.
Ścieżka skryptu: main.py
"""

import pygame
import sys
import math
import random

# --- KONFIGURACJA GLOBALNA ---
WERSJA = "7.0_Final_Stable"
SZEROKOSC, WYSOKOSC = 1280, 960
FPS = 60
ROZMIAR_BLOKU = 32

KOLOR_UI = (255, 255, 255)
KOLOR_BTN = (40, 40, 50)

FOV = math.pi / 3  
HALF_FOV = FOV / 2
NUM_RAYS = 320  
MAX_DEPTH = 800  
SCREEN_DIST = (SZEROKOSC / 2) / math.tan(HALF_FOV)
PROJ_COEFF = ROZMIAR_BLOKU * SCREEN_DIST
SCALE = SZEROKOSC // NUM_RAYS

LAB_SZEROKOSC = 41
LAB_WYSOKOSC = 41

class GraHorror3D:
    def __init__(self):
        pygame.init()
        self.ekran = pygame.display.set_mode((SZEROKOSC, WYSOKOSC))
        pygame.display.set_caption(f"No Signal 3D - Stable (v{WERSJA})")
        self.zegar = pygame.time.Clock()

        self.dziala = True
        self.stan_menu = 'wpisywanie_nicku'  
        
        self.latarka_wlaczona = True
        self.mysz_zainicjalizowana = False
        self.mysz_zablokowana = True  

        self.moje_x = 48.0
        self.moje_y = 48.0
        self.moje_kat = 0.0  
        self.moje_pitch = 0.0  
        self.predkosc_ruchu = 2.2  
        self.czulosc_myszy = 0.0025
        self.idzie_teraz = False  

        self.licznik_chodzenia = 0.0
        self.bujanie_glowy_y = 0.0
        self.bateria = 100.0
        self.max_bateria = 100.0

        self.moj_nick = "Gracz"
        
        self.ma_klucz = False
        self.klucz_x = 100.0
        self.klucz_y = 100.0
        
        self.drzwi_kafelki = set()
        self.mapa_struktura = []
        
        self.font_main = pygame.font.SysFont("Arial", 32)
        self.font_small = pygame.font.SysFont("Arial", 24)
        self.font_big = pygame.font.SysFont("Arial", 40)

        self.btn_single = pygame.Rect(100, 200, 500, 60)
        self.tekstura_cegiel = self.generuj_teksture_cegiel()

    def generuj_teksture_cegiel(self):
        tekstura = []
        for y in range(ROZMIAR_BLOKU):
            wiersz = []
            for x in range(ROZMIAR_BLOKU):
                fuga_pozioma = (y % 8 == 0) or (y == ROZMIAR_BLOKU - 1)
                row_idx = y // 8
                if row_idx % 2 == 0:
                    fuga_pionowa = (x % 16 == 0) or (x == ROZMIAR_BLOKU - 1)
                else:
                    fuga_pionowa = ((x + 8) % 16 == 0) or (x == ROZMIAR_BLOKU - 1)

                if fuga_pozioma or fuga_pionowa:
                    color = (20, 20, 20)
                else:
                    jasnosc = 80 + ((x * y + x) % 40)
                    color = (jasnosc, jasnosc, jasnosc)
                wiersz.append(color)
            tekstura.append(wiersz)
        return tekstura

    def generuj_labirynt(self):
        szer, wys = LAB_SZEROKOSC, LAB_WYSOKOSC
        self.mapa_struktura = [[1 for _ in range(szer)] for _ in range(wys)]
        self.drzwi_kafelki.clear()

        odwiedzone = set()
        stos = [(1, 1)]
        self.mapa_struktura[1][1] = 0
        odwiedzone.add((1, 1))

        while stos:
            cx, cy = stos[-1]
            sasiedzi = []
            
            kierunki = [(0, -2), (2, 0), (0, 2), (-2, 0)]
            for dx, dy in kierunki:
                nx, ny = cx + dx, cy + dy
                if 0 < nx < szer - 1 and 0 < ny < wys - 1:
                    if (nx, ny) not in odwiedzone:
                        sasiedzi.append((nx, ny, dx // 2, dy // 2))
            
            if sasiedzi:
                nx, ny, d_x, d_y = random.choice(sasiedzi)
                self.mapa_struktura[cy + d_y][cx + d_x] = 0
                self.mapa_struktura[ny][nx] = 0
                
                odwiedzone.add((nx, ny))
                stos.append((nx, ny))
            else:
                stos.pop()

        # Dodanie pętli korytarzy
        for _ in range((szer * wys) // 10):
            rx = random.randint(2, szer - 3)
            ry = random.randint(2, wys - 3)
            if self.mapa_struktura[ry][rx] == 1:
                if self.mapa_struktura[ry-1][rx] == 0 and self.mapa_struktura[ry+1][rx] == 0:
                    self.mapa_struktura[ry][rx] = 0
                elif self.mapa_struktura[ry][rx-1] == 0 and self.mapa_struktura[ry][rx+1] == 0:
                    self.mapa_struktura[ry][rx] = 0

        wolne_punkty = []
        for y in range(1, wys - 1):
            for x in range(1, szer - 1):
                if self.mapa_struktura[y][x] == 0 and (x > 4 or y > 4):
                    wolne_punkty.append((x, y))

        # ZABEZPIECZENIE: Jeśli z jakiegoś powodu lista jest pusta, tworzymy sztuczne punkty
        if len(wolne_punkty) < 2:
            wolne_punkty = [(szer - 2, wys - 2), (szer - 2, wys - 3)]
        
        random.shuffle(wolne_punkty)

        kx, ky = wolne_punkty.pop()
        self.klucz_x = kx * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
        self.klucz_y = ky * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2

        dx, dy = wolne_punkty.pop()
        self.mapa_struktura[dy][dx] = 2
        self.drzwi_kafelki.add((dx, dy))

        self.moje_x = 1 * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
        self.moje_y = 1 * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
        
        self.ma_klucz = False
        self.moje_kat = 0.0
        self.moje_pitch = 0.0

    def ruch_i_kolizje(self, dx, dy):
        PROMIEN_GRACZA = 10  
        
        nowe_x = self.moje_x + dx
        margines_x = PROMIEN_GRACZA if dx > 0 else -PROMIEN_GRACZA
        map_x = int((nowe_x + margines_x) // ROZMIAR_BLOKU)
        map_y = int(self.moje_y // ROZMIAR_BLOKU)
        
        if 0 <= map_x < LAB_SZEROKOSC and 0 <= map_y < LAB_WYSOKOSC:
            if self.mapa_struktura[map_y][map_x] in [0, 2]:
                self.moje_x = nowe_x

        nowe_y = self.moje_y + dy
        margines_y = PROMIEN_GRACZA if dy > 0 else -PROMIEN_GRACZA
        map_x = int(self.moje_x // ROZMIAR_BLOKU)
        map_y = int((nowe_y + margines_y) // ROZMIAR_BLOKU)
        
        if 0 <= map_x < LAB_SZEROKOSC and 0 <= map_y < LAB_WYSOKOSC:
            if self.mapa_struktura[map_y][map_x] in [0, 2]:
                self.moje_y = nowe_y

        curr_x = int(self.moje_x // ROZMIAR_BLOKU)
        curr_y = int(self.moje_y // ROZMIAR_BLOKU)
        if (curr_x, curr_y) in self.drzwi_kafelki and self.ma_klucz:
            self.stan_menu = 'glowne_menu'
            self.mysz_zablokowana = False
            pygame.mouse.set_visible(True)
            pygame.event.set_grab(False)

    def rysuj_scene_3d(self):
        self.ekran.fill((0, 0, 0)) 
        
        centr_y = WYSOKOSC // 2 + self.moje_pitch + self.bujanie_glowy_y
        z_buffer = [MAX_DEPTH] * NUM_RAYS
        kat_startowy = self.moje_kat - HALF_FOV

        for ray in range(NUM_RAYS):
            kat_promienia = kat_startowy + ray * (FOV / NUM_RAYS)
            sin_a = math.sin(kat_promienia)
            cos_a = math.cos(kat_promienia)

            for glebokosc in range(1, MAX_DEPTH, 2):
                cel_x = self.moje_x + glebokosc * cos_a
                cel_y = self.moje_y + glebokosc * sin_a

                b_x = int(cel_x // ROZMIAR_BLOKU)
                b_y = int(cel_y // ROZMIAR_BLOKU)

                if 0 <= b_x < LAB_SZEROKOSC and 0 <= b_y < LAB_WYSOKOSC:
                    typ_bloku = self.mapa_struktura[b_y][b_x]
                    
                    if typ_bloku in [1, 2]:
                        glebokosc_kor = glebokosc * math.cos(kat_promienia - self.moje_kat)
                        glebokosc_kor = max(glebokosc_kor, 0.0001)
                        z_buffer[ray] = glebokosc_kor
                        
                        wysokosc_sciany = int(PROJ_COEFF / glebokosc_kor)
                        wall_top = centr_y - wysokosc_sciany // 2

                        hit_x = cel_x % ROZMIAR_BLOKU
                        hit_y = cel_y % ROZMIAR_BLOKU
                        if abs(hit_x - 0) < 1 or abs(hit_x - (ROZMIAR_BLOKU-1)) < 1:
                            tex_x = int(hit_y)
                        else:
                            tex_x = int(hit_x)
                        tex_x = max(0, min(ROZMIAR_BLOKU - 1, tex_x))

                        roznica_srodka = kat_promienia - self.moje_kat
                        roznica_srodka = (roznica_srodka + math.pi) % (2 * math.pi) - math.pi
                        
                        # --- MODYFIKATOR LATARKI I MROKU ---
                        if self.latarka_wlaczona:
                            MAX_WIDOCZNOSC = 500
                            ST_LATARKI = math.pi / 3.8
                            if abs(roznica_srodka) < ST_LATARKI:
                                wsp_swiatla = max(0.0, 1.0 - (glebokosc / MAX_WIDOCZNOSC))
                                wsp_swiatla *= (1.0 - (abs(roznica_srodka) / ST_LATARKI))
                            else: 
                                wsp_swiatla = 0.0
                        else:
                            # TWARDE OGRANICZENIE WIDZENIA BEZ ŚWIATŁA (max ~60 jednostek, czyli niecałe 2 klocki)
                            if glebokosc < 60:
                                wsp_swiatla = max(0.0, 1.0 - (glebokosc / 60)) * 0.12
                            else:
                                wsp_swiatla = 0.0  # Całkowita, nieprzenikniona czerń

                        if wsp_swiatla > 0.001:
                            if typ_bloku == 1:
                                for ty in range(ROZMIAR_BLOKU):
                                    p_kolor = self.tekstura_cegiel[ty][tex_x]
                                    r = int(p_kolor[0] * wsp_swiatla)
                                    g = int(p_kolor[1] * wsp_swiatla)
                                    b = int(p_kolor[2] * wsp_swiatla)
                                    
                                    segment_h = wysokosc_sciany / ROZMIAR_BLOKU
                                    seg_top = wall_top + int(ty * segment_h)
                                    seg_size = max(1, int(segment_h) + 1)
                                    pygame.draw.rect(self.ekran, (r, g, b), (ray * SCALE, seg_top, SCALE, seg_size))
                            
                            elif typ_bloku == 2:
                                r = int(120 * wsp_swiatla)
                                g = int(60 * wsp_swiatla)
                                b = int(30 * wsp_swiatla)
                                if tex_x % 8 == 0 or tex_x == ROZMIAR_BLOKU - 1:
                                    r, g, b = int(r * 0.4), int(g * 0.4), int(b * 0.4)
                                pygame.draw.rect(self.ekran, (r, g, b), (ray * SCALE, wall_top, SCALE, wysokosc_sciany))
                        break

        # --- TRÓJWYMIAROWY KLUCZ ---
        if not self.ma_klucz:
            dx = self.klucz_x - self.moje_x
            dy = self.klucz_y - self.moje_y
            dystans = math.hypot(dx, dy)

            theta = math.atan2(dy, dx)
            gamma = theta - self.moje_kat
            gamma = (gamma + math.pi) % (2 * math.pi) - math.pi  

            if -HALF_FOV < gamma < HALF_FOV and dystans > 5:
                dystans_kor = max(dystans * math.cos(gamma), 0.0001)
                limit_klucza = MAX_DEPTH if self.latarka_wlaczona else 60
                
                if dystans_kor < limit_klucza:
                    screen_x = int((SZEROKOSC / 2) + math.tan(gamma) * SCREEN_DIST)
                    wysokosc_sciany = int(PROJ_COEFF / dystans_kor)
                    
                    klucz_h = int(wysokosc_sciany * 0.4)
                    klucz_w = max(3, int(klucz_h * 0.25))
                    
                    center_y_klucz = centr_y + int(wysokosc_sciany * 0.15)
                    klucz_top = center_y_klucz - klucz_h // 2
                    
                    ray_idx = screen_x // SCALE
                    if 0 <= ray_idx < NUM_RAYS and dystans_kor < z_buffer[ray_idx]:
                        wsp_k = max(0.1, 1.0 - (dystans_kor / 450)) if self.latarka_wlaczona else max(0.0, 1.0 - (dystans_kor / 60)) * 0.2
                        if wsp_k > 0.01:
                            kolor_klucza = (int(255 * wsp_k), int(215 * wsp_k), int(0 * wsp_k))
                            pygame.draw.rect(self.ekran, kolor_klucza, (screen_x - klucz_w // 2, klucz_top, klucz_w, klucz_h))

        # --- UI GRY ---
        pygame.draw.circle(self.ekran, (140, 140, 140), (SZEROKOSC // 2, WYSOKOSC // 2), 2)

        pygame.draw.rect(self.ekran, (30, 30, 30), (20, 20, 200, 25))
        kolor_baterii = (50, 200, 70) if self.bateria > 20 else (220, 40, 40)
        pygame.draw.rect(self.ekran, kolor_baterii, (20, 20, int(self.bateria * 2), 25))
        
        status_tekst = "STATUS: Szukaj klucza" if not self.ma_klucz else "STATUS: Znajdź brązowe drzwi wyjściowe!"
        kolor_statusu = (235, 210, 40) if not self.ma_klucz else (40, 235, 90)
        txt_status = self.font_small.render(status_tekst, True, kolor_statusu)
        self.ekran.blit(txt_status, (250, 18))

        if not self.ma_klucz:
            dst_do_klucza = math.hypot(self.klucz_x - self.moje_x, self.klucz_y - self.moje_y)
            if dst_do_klucza < 45:
                txt_action = self.font_main.render("Naciśnij [F], aby podnieść ZŁOTY KLUCZ", True, (255, 255, 100))
                self.ekran.blit(txt_action, (SZEROKOSC // 2 - txt_action.get_width() // 2, WYSOKOSC - 150))

    def zablokuj_mysz_gry(self):
        self.mysz_zablokowana = True
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
        pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
        self.mysz_zainicjalizowana = False

    def obsluga_zdarzen(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.dziala = False
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if self.stan_menu == 'wpisywanie_nicku':
                    if event.key == pygame.K_RETURN and self.moj_nick.strip():
                        self.stan_menu = 'glowne_menu'
                    elif event.key == pygame.K_BACKSPACE: self.moj_nick = self.moj_nick[:-1]
                    else:
                        if len(self.moj_nick) < 14 and (event.unicode.isalnum() or event.unicode in [' ', '_', '-']):
                            self.moj_nick += event.unicode

                elif self.stan_menu == 'gra':
                    if event.key == pygame.K_ESCAPE:
                        self.mysz_zablokowana = not self.mysz_zablokowana
                        pygame.mouse.set_visible(not self.mysz_zablokowana)
                        pygame.event.set_grab(self.mysz_zablokowana)
                    
                    if event.key == pygame.K_f:
                        dst_do_klucza = math.hypot(self.klucz_x - self.moje_x, self.klucz_y - self.moje_y)
                        if dst_do_klucza < 45 and not self.ma_klucz:
                            self.ma_klucz = True
                        else:
                            if self.bateria > 0:
                                self.latarka_wlaczona = not self.latarka_wlaczona

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = pygame.mouse.get_pos()
                
                if self.stan_menu == 'glowne_menu':
                    if self.btn_single.collidepoint(pos):
                        self.generuj_labirynt()
                        self.stan_menu = 'gra'
                        self.zablokuj_mysz_gry()

                elif self.stan_menu == 'gra' and not self.mysz_zablokowana:
                    self.zablokuj_mysz_gry()

    def aktualizacja(self):
        if self.stan_menu != 'gra': return

        if self.mysz_zablokowana:
            mx, my = pygame.mouse.get_pos()
            if not self.mysz_zainicjalizowana:
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
                self.mysz_zainicjalizowana = True
            else:
                self.moje_kat += (mx - SZEROKOSC // 2) * self.czulosc_myszy
                self.moje_pitch = max(-260, min(260, self.moje_pitch - (my - WYSOKOSC // 2) * 1.2))
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)

        klawisze = pygame.key.get_pressed()
        dx, dy = 0.0, 0.0
        cos_a, sin_a = math.cos(self.moje_kat), math.sin(self.moje_kat)

        idzie = False
        if klawisze[pygame.K_w]: dx += cos_a; dy += sin_a; idzie = True
        if klawisze[pygame.K_s]: dx -= cos_a; dy -= sin_a; idzie = True
        if klawisze[pygame.K_a]: dx += sin_a; dy -= cos_a; idzie = True
        if klawisze[pygame.K_d]: dx -= sin_a; dy += cos_a; idzie = True

        self.idzie_teraz = idzie

        if idzie:
            dl = math.hypot(dx, dy)
            self.ruch_i_kolizje((dx / dl) * self.predkosc_ruchu, (dy / dl) * self.predkosc_ruchu)
            self.licznik_chodzenia += 0.22
            self.bujanie_glowy_y = math.sin(self.licznik_chodzenia) * 5.0
        else:
            self.bujanie_glowy_y *= 0.75

        if self.latarka_wlaczona:
            self.bateria = max(0, self.bateria - 0.025)
            if self.bateria == 0: self.latarka_wlaczona = False
        else: 
            self.bateria = min(self.max_bateria, self.bateria + 0.015)

    def rysuj_ui(self):
        self.ekran.fill((15, 15, 20))
        
        if self.stan_menu == 'wpisywanie_nicku':
            txt_t = self.font_big.render("NO SIGNAL: 3D HORROR", True, (210, 20, 20))
            self.ekran.blit(txt_t, (SZEROKOSC // 2 - txt_t.get_width() // 2, 220))
            txt_p = self.font_main.render("Wpisz swój nick i naciśnij ENTER:", True, KOLOR_UI)
            self.ekran.blit(txt_p, (SZEROKOSC // 2 - txt_p.get_width() // 2, 420))
            txt_n = self.font_big.render(self.moj_nick + "_", True, (240, 240, 250))
            self.ekran.blit(txt_n, (SZEROKOSC // 2 - txt_n.get_width() // 2, 500))

        elif self.stan_menu == 'glowne_menu':
            txt_t = self.font_big.render(f"Witaj, {self.moj_nick}! Wybierz tryb:", True, KOLOR_UI)
            self.ekran.blit(txt_t, (100, 100))

            pygame.draw.rect(self.ekran, KOLOR_BTN, self.btn_single)
            self.ekran.blit(self.font_main.render("GENERUJ LABIRYNT i GRAJ", True, KOLOR_UI), (self.btn_single.x + 15, self.btn_single.y + 12))

            txt_desc = self.font_small.render("Cel: Znajdź Złoty Klucz, podejdź i wciśnij [F], a następnie ucieknij przez Brązowe Drzwi.", True, (160, 160, 170))
            self.ekran.blit(txt_desc, (100, 320))

    def run(self):
        while self.dziala:
            self.obsluga_zdarzen()
            self.aktualizacja()
            if self.stan_menu == 'gra': self.rysuj_scene_3d()
            else: self.rysuj_ui()
            pygame.display.flip()
            self.zegar.tick(FPS)

if __name__ == "__main__":
    gra = GraHorror3D()
    gra.run()
