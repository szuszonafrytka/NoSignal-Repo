"""
main.py - No Signal: 3D Horror Game [MULTIPLAYER v3.3]
Naprawiono: Implementacja absolutnego mroku i stożka oświetlenia gracza.
Ściany poza zasięgiem światła całkowicie znikają w czerni, realnie ograniczając pole widzenia.
"""

import pygame
import socket
import threading
import time
import sys
import random
import math

# --- KONFIGURACJA GLOBALNA ---
SZEROKOSC, WYSOKOSC = 1280, 960
FPS = 60
MAPA_W, MAPA_H = 40, 30
ROZMIAR_BLOKU = 32

# Kolory klimatyczne
KOLOR_UI = (255, 255, 255)
KOLOR_BTN = (40, 40, 50)

# Parametry silnika 3D
FOV = math.pi / 3  
HALF_FOV = FOV / 2
NUM_RAYS = 320  
MAX_DEPTH = 650  
SCREEN_DIST = (SZEROKOSC / 2) / math.tan(HALF_FOV)
PROJ_COEFF = ROZMIAR_BLOKU * SCREEN_DIST
SCALE = SZEROKOSC // NUM_RAYS

PORT_BROADCAST = 5556

class GraHorror3D:
    def __init__(self):
        pygame.init()
        self.ekran = pygame.display.set_mode((SZEROKOSC, WYSOKOSC))
        pygame.display.set_caption("No Signal 3D - Multiplayer Horror")
        self.zegar = pygame.time.Clock()

        # Stan gry
        self.fullscreen = False
        self.latarka_wlaczona = True
        self.dziala = True
        self.rola = 'wpisywanie_nicku'  
        self.mysz_zainicjalizowana = False
        self.mysz_zablokowana = True  

        # Dane gracza i kamery
        self.moje_x = 48.0
        self.moje_y = 48.0
        self.moje_kat = 0.0  
        self.moje_pitch = 0.0  
        self.predkosc_ruchu = 1.6  
        self.czulosc_myszy = 0.0025
        self.idzie_teraz = False  

        # Animacja ruszania głową (View Bobbing)
        self.licznik_chodzenia = 0.0
        self.bujanie_glowy_y = 0.0

        # System baterii latarki
        self.bateria = 100.0
        self.max_bateria = 100.0

        self.moj_nick = "Gracz"
        self.nazwa_serwera = "Serwer LAN"
        
        self.mapa = []
        
        self.font_main = pygame.font.SysFont("Arial", 32)
        self.font_small = pygame.font.SysFont("Arial", 24)
        self.font_big = pygame.font.SysFont("Arial", 40)

        # Sieć
        self.wybrany_serwer_ip = None
        self.wybrany_serwer_port = 5555
        self.wykryte_serwery = {}
        self.klienci = {}
        self.inni_gracze = {}

        # UI
        self.btn_single = pygame.Rect(100, 200, 500, 60)
        self.btn_host = pygame.Rect(100, 300, 500, 60)
        self.serwery_przyciski = []

    def generuj_mape(self):
        # Stały seed zapewnia identyczną mapę dla wszystkich graczy w sieci LAN
        random.seed(1337)
        self.mapa = [[1 for _ in range(MAPA_W)] for _ in range(MAPA_H)]
        for y in range(1, MAPA_H - 1):
            for x in range(1, MAPA_W - 1):
                if random.random() < 0.22:
                    self.mapa[y][x] = 1
                else:
                    self.mapa[y][x] = 0
        self.mapa[1][1] = 0
        self.mapa[1][2] = 0
        self.mapa[2][1] = 0

    # --- TRANSMISJA UDP ---

    def nadawaj_obecnosc(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while self.dziala and self.rola == 'serwer':
            try:
                msg = f"3D_HORROR_SRV:{self.nazwa_serwera}:5555".encode('utf-8')
                s.sendto(msg, ('<broadcast>', PORT_BROADCAST))
            except: pass
            time.sleep(1)

    def sluchaj_obecnosci(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('', PORT_BROADCAST))
        s.settimeout(0.5)
        while self.dziala:
            if self.rola in [None, 'wpisywanie_nazwy', 'wpisywanie_nicku', 'menu']:
                try:
                    dane, adres = s.recvfrom(1024)
                    tekst = dane.decode('utf-8', errors='ignore')
                    if tekst.startswith("3D_HORROR_SRV:"):
                        parts = tekst.split(":")
                        if len(parts) >= 3:
                            self.wykryte_serwery[parts[1].strip()] = (adres[0], int(parts[2]), time.time())
                except: pass
                teraz = time.time()
                nieaktywne = [n for n, (ip, p, t) in self.wykryte_serwery.items() if teraz - t > 4.0]
                for n in nieaktywne: del self.wykryte_serwery[n]
            else:
                time.sleep(0.5)

    def odpal_serwer_sieciowy(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try: s.bind(('', 5555))
        except: pass
        s.settimeout(0.5)
        while self.dziala and self.rola == 'serwer':
            try:
                dane, adres = s.recvfrom(1024)
                paczka = dane.decode().split(",")
                key = f"{adres[0]}:{adres[1]}"
                nick_nowy = paczka[3]
                latarka_status = int(paczka[4])
                ruch_status = int(paczka[5]) if len(paczka) >= 6 else 0

                stare_klony = [k for k, v in self.klienci.items() if v['nick'] == nick_nowy and k != key]
                for k in stare_klony: del self.klienci[k]

                self.klienci[key] = {
                    'x': float(paczka[0]), 'y': float(paczka[1]), 
                    'kat': float(paczka[2]), 'nick': nick_nowy, 
                    'latarka': latarka_status, 'idzie': ruch_status, 'czas': time.time()
                }

                res = f"{self.moje_x};{self.moje_y};{self.moje_kat};{self.moj_nick};{int(self.latarka_wlaczona)};{int(self.idzie_teraz)}|"
                for k_id, data in self.klienci.items():
                    if k_id != key:
                        res += f"{data['x']};{data['y']};{data['kat']};{data['nick']};{data['latarka']};{data['idzie']}|"
                s.sendto(res.encode(), adres)
            except: pass
            teraz = time.time()
            rozlaczeni = [k for k, v in self.klienci.items() if teraz - v['czas'] > 3.0]
            for k in rozlaczeni: del self.klienci[k]

    def odpal_klienta_sieciowy(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(1)
        while self.dziala and self.rola == 'klient':
            try:
                payload = f"{self.moje_x},{self.moje_y},{self.moje_kat},{self.moj_nick},{int(self.latarka_wlaczona)},{int(self.idzie_teraz)}"
                s.sendto(payload.encode(), (self.wybrany_serwer_ip, self.wybrany_serwer_port))
                dane, _ = s.recvfrom(2048)
                
                nowi_gracze = {}
                for i, czesc in enumerate(dane.decode().split("|")):
                    if czesc:
                        elementy = czesc.split(";")
                        if len(elementy) >= 6:
                            x_s, y_s, kat_s, n_s, lat_s, idz_s = elementy[:6]
                            nowi_gracze[i] = {
                                'x': float(x_s), 'y': float(y_s), 'kat': float(kat_s), 
                                'nick': n_s, 'latarka': int(lat_s), 'idzie': int(idz_s)
                            }
                self.inni_gracze = nowi_gracze
            except: self.inni_gracze = {}
            time.sleep(0.02)

    def ruch_i_kolizje(self, dx, dy):
        PROMIEN_GRACZA = 12  
        nowe_x = self.moje_x + dx
        margines_x = PROMIEN_GRACZA if dx > 0 else -PROMIEN_GRACZA
        if self.mapa[int(self.moje_y // ROZMIAR_BLOKU)][int((nowe_x + margines_x) // ROZMIAR_BLOKU)] == 0:
            self.moje_x = nowe_x
            
        nowe_y = self.moje_y + dy
        margines_y = PROMIEN_GRACZA if dy > 0 else -PROMIEN_GRACZA
        if self.mapa[int((nowe_y + margines_y) // ROZMIAR_BLOKU)][int(self.moje_x // ROZMIAR_BLOKU)] == 0:
            self.moje_y = nowe_y

    # --- RAYCASTER Z ABSOLUTNYM MROKIEM (FOG OF WAR) ---

    def rysuj_scene_3d(self):
        centr_y = WYSOKOSC // 2 + self.moje_pitch + self.bujanie_glowy_y

        # Idealnie czarne tło nocy. Ściany bez światła stopią się z nim w 100%
        pygame.draw.rect(self.ekran, (0, 0, 0), (0, 0, SZEROKOSC, WYSOKOSC))

        dane_graczy = self.klienci.values() if self.rola == 'serwer' else self.inni_gracze.values()
        z_buffer = [MAX_DEPTH] * NUM_RAYS

        # Renderowanie ścian
        kat_startowy = self.moje_kat - HALF_FOV
        for ray in range(NUM_RAYS):
            kat_promienia = kat_startowy + ray * (FOV / NUM_RAYS)
            sin_a = math.sin(kat_promienia)
            cos_a = math.cos(kat_promienia)

            for glebokosc in range(1, MAX_DEPTH, 1):
                cel_x = self.moje_x + glebokosc * cos_a
                cel_y = self.moje_y + glebokosc * sin_a

                b_x = int(cel_x // ROZMIAR_BLOKU)
                b_y = int(cel_y // ROZMIAR_BLOKU)

                if 0 <= b_x < MAPA_W and 0 <= b_y < MAPA_H:
                    if self.mapa[b_y][b_x] == 1:
                        glebokosc_kor = glebokosc * math.cos(kat_promienia - self.moje_kat)
                        glebokosc_kor = max(glebokosc_kor, 0.0001)
                        
                        z_buffer[ray] = glebokosc_kor
                        wysokosc_sciany = int(PROJ_COEFF / glebokosc_kor)
                        wall_top = centr_y - wysokosc_sciany // 2

                        # 1. Obliczanie oświetlenia własnej latarki (STOŻEK LATARKI GRACZA)
                        roznica_srodka = kat_promienia - self.moje_kat
                        roznica_srodka = (roznica_srodka + math.pi) % (2 * math.pi) - math.pi

                        if self.latarka_wlaczona:
                            MAX_WIDOCZNOSC = 450
                            ST_LATARKI = math.pi / 4  # Kąt rozwarcia Twojej latarki
                            if abs(roznica_srodka) < ST_LATARKI:
                                wsp_swiatla = max(0.0, 1.0 - (glebokosc / MAX_WIDOCZNOSC))
                                # Efekt snopu latarki: ściemnianie obrazu w kierunku krawędzi ekranu
                                wsp_swiatla *= (1.0 - (abs(roznica_srodka) / ST_LATARKI))
                            else:
                                wsp_swiatla = 0.0
                        else:
                            # Totalny mrok bez latarki - widzisz tylko na odległość wyciągniętej ręki
                            MAX_WIDOCZNOSC = 65
                            wsp_swiatla = max(0.0, 1.0 - (glebokosc / MAX_WIDOCZNOSC)) * 0.2

                        # 2. Dynamiczny stożek światła od latarek innych graczy
                        for d in dane_graczy:
                            if d.get('latarka', 0) == 1:
                                dx_k = cel_x - d['x']
                                dy_k = cel_y - d['y']
                                dystans_kumpla_do_sciany = math.hypot(dx_k, dy_k)

                                if dystans_kumpla_do_sciany < 450:
                                    kat_do_sciany = math.atan2(dy_k, dx_k)
                                    roznica_kata = (kat_do_sciany - d['kat'] + math.pi) % (2 * math.pi) - math.pi

                                    SZEROKOSC_STOZKA = math.pi / 5
                                    if abs(roznica_kata) < SZEROKOSC_STOZKA:
                                        wsp_kumpla = max(0.0, 1.0 - (dystans_kumpla_do_sciany / 450))
                                        wsp_kumpla *= (1.0 - (abs(roznica_kata) / SZEROKOSC_STOZKA))
                                        
                                        if wsp_kumpla > wsp_swiatla:
                                            wsp_swiatla = wsp_kumpla

                        # Rysuj tylko, jeśli fragment ściany jest realnie oświetlony
                        if wsp_swiatla > 0.0:
                            r = int(140 * wsp_swiatla)
                            g = int(15 * wsp_swiatla)
                            b = int(15 * wsp_swiatla)
                            pygame.draw.rect(self.ekran, (r, g, b), (ray * SCALE, wall_top, SCALE, wysokosc_sciany))
                        break

        # Renderowanie modeli graczy
        t_time = time.time()
        for d in dane_graczy:
            dx = d['x'] - self.moje_x
            dy = d['y'] - self.moje_y
            dystans = math.hypot(dx, dy)

            theta = math.atan2(dy, dx)
            gamma = theta - self.moje_kat
            gamma = (gamma + math.pi) % (2 * math.pi) - math.pi  

            # Obliczanie widoczności ciała innego gracza w ciemności
            wsp_moje_na_kumplu = 0.0
            if self.latarka_wlaczona:
                ST_LATARKI = math.pi / 4
                if abs(gamma) < ST_LATARKI and dystans < 450:
                    wsp_moje_na_kumplu = max(0.0, 1.0 - (dystans / 450))
                    wsp_moje_na_kumplu *= (1.0 - (abs(gamma) / ST_LATARKI))
            else:
                if dystans < 65:
                    wsp_moje_na_kumplu = max(0.0, 1.0 - (dystans / 65)) * 0.2

            wsp_sw_kumpla = wsp_moje_na_kumplu
            
            kumpel_swieci = d.get('latarka', 0) == 1
            if kumpel_swieci:
                wsp_sw_kumpla = max(wsp_sw_kumpla, 0.40) # Rozświetla się sam

            # Czy ktoś trzeci oświetla tego gracza?
            for trzeci in dane_graczy:
                if trzeci != d and trzeci.get('latarka', 0) == 1:
                    dx_t = d['x'] - trzeci['x']
                    dy_t = d['y'] - trzeci['y']
                    dyst_t = math.hypot(dx_t, dy_t)
                    if dyst_t < 450:
                        kat_t = math.atan2(dy_t, dx_t)
                        roz_t = (kat_t - trzeci['kat'] + math.pi) % (2 * math.pi) - math.pi
                        if abs(roz_t) < math.pi / 5:
                            wsp_trzeci = max(0.0, 1.0 - (dyst_t / 450)) * (1.0 - (abs(roz_t) / (math.pi / 5)))
                            wsp_sw_kumpla = max(wsp_sw_kumpla, wsp_trzeci)

            # Rysuj model gracza wyłącznie, gdy jest widoczny w ciemności
            if -HALF_FOV < gamma < HALF_FOV and wsp_sw_kumpla > 0.0:
                dystans_kor = dystans * math.cos(gamma)
                dystans_kor = max(dystans_kor, 0.0001)

                screen_x = int((SZEROKOSC / 2) + math.tan(gamma) * SCREEN_DIST)
                wysokosc_sciany = int(PROJ_COEFF / dystans_kor)
                wysokosc_postaci = int(wysokosc_sciany * 0.55)  
                szerokosc_postaci = int(wysokosc_postaci * 0.46) 
                
                player_bottom = centr_y + wysokosc_sciany // 2  
                player_top = player_bottom - wysokosc_postaci
                
                kat_do_mnie = math.atan2(self.moje_y - d['y'], self.moje_x - d['x'])
                roznica_katowa = (kat_do_mnie - d['kat'] + math.pi) % (2 * math.pi) - math.pi

                if abs(roznica_katowa) < math.pi / 4: strona = 'FRONT'  
                elif abs(roznica_katowa) > 3 * math.pi / 4: strona = 'BACK'   
                elif roznica_katowa >= 0: strona = 'LEFT'   
                else: strona = 'RIGHT'  

                kumpel_idzie = d.get('idzie', 0) == 1
                faza = math.sin(t_time * 14) if kumpel_idzie else 0.0
                swing = int(faza * (wysokosc_postaci * 0.05))

                start_ray = max(0, (screen_x - szerokosc_postaci // 2) // SCALE)
                end_ray = min(NUM_RAYS - 1, (screen_x + szerokosc_postaci // 2) // SCALE)

                h_glowy = int(wysokosc_postaci * 0.20)
                h_tulowia = int(wysokosc_postaci * 0.40)
                h_nog = int(wysokosc_postaci * 0.30)

                y_gl_s, y_gl_e = player_top, player_top + h_glowy
                y_tl_s, y_tl_e = y_gl_e, y_gl_e + h_tulowia
                y_ng_s, y_ng_e = y_tl_e, y_tl_e + h_nog
                y_bt_s, y_bt_e = y_ng_e, player_bottom

                for r in range(start_ray, end_ray + 1):
                    if dystans_kor < z_buffer[r]:
                        rel_x = (r * SCALE - (screen_x - szerokosc_postaci // 2)) / szerokosc_postaci if szerokosc_postaci > 0 else 0.5

                        def rysuj_piksele(y1, y2, kolor):
                            if y2 > y1:
                                rc = int(kolor[0] * wsp_sw_kumpla)
                                gc = int(kolor[1] * wsp_sw_kumpla)
                                bc = int(kolor[2] * wsp_sw_kumpla)
                                pygame.draw.rect(self.ekran, (rc, gc, bc), (r * SCALE, y1, SCALE, y2 - y1))

                        if strona == 'FRONT':
                            if 0.30 <= rel_x <= 0.70:
                                rysuj_piksele(y_gl_s, y_gl_s + int(h_glowy * 0.25), (35, 25, 20)) 
                                rysuj_piksele(y_gl_s + int(h_glowy * 0.25), y_gl_e, (215, 150, 120)) 
                                if (0.38 <= rel_x <= 0.45) or (0.55 <= rel_x <= 0.62):
                                    rysuj_piksele(y_gl_s + int(h_glowy * 0.45), y_gl_s + int(h_glowy * 0.55), (255, 30, 30))
                            if 0.12 <= rel_x <= 0.24: rysuj_piksele(y_tl_s + swing, y_tl_e - int(h_tulowia * 0.1) + swing, (55, 65, 60))
                            elif 0.76 <= rel_x <= 0.88: rysuj_piksele(y_tl_s - swing, y_tl_e - int(h_tulowia * 0.1) - swing, (55, 65, 60))
                            elif 0.24 < rel_x < 0.76: 
                                rysuj_piksele(y_tl_s, y_tl_e, (55, 65, 60))
                                if 0.36 <= rel_x <= 0.64: rysuj_piksele(y_tl_s + int(h_tulowia * 0.15), y_tl_s + int(h_tulowia * 0.75), (25, 26, 30))
                            if 0.24 <= rel_x <= 0.46:
                                skroc = int(abs(swing)) if swing > 0 else 0
                                rysuj_piksele(y_ng_s, y_bt_s - skroc, (40, 45, 65))
                                rysuj_piksele(y_bt_s - skroc, y_bt_e - skroc, (20, 20, 22))
                            elif 0.54 <= rel_x <= 0.76:
                                skroc = int(abs(swing)) if swing < 0 else 0
                                rysuj_piksele(y_ng_s, y_bt_s - skroc, (40, 45, 65))
                                rysuj_piksele(y_bt_s - skroc, y_bt_e - skroc, (20, 20, 22))
                        elif strona == 'BACK':
                            if 0.30 <= rel_x <= 0.70: rysuj_piksele(y_gl_s, y_gl_e, (35, 25, 20))
                            if 0.12 <= rel_x <= 0.24: rysuj_piksele(y_tl_s - swing, y_tl_e - int(h_tulowia * 0.1) - swing, (55, 65, 60))
                            elif 0.76 <= rel_x <= 0.88: rysuj_piksele(y_tl_s + swing, y_tl_e - int(h_tulowia * 0.1) + swing, (55, 65, 60))
                            elif 0.24 < rel_x < 0.76: rysuj_piksele(y_tl_s, y_tl_e, (55, 65, 60))
                            if 0.24 <= rel_x <= 0.46:
                                skroc = int(abs(swing)) if swing < 0 else 0
                                rysuj_piksele(y_ng_s, y_bt_s - skroc, (40, 45, 65))
                            elif 0.54 <= rel_x <= 0.76:
                                skroc = int(abs(swing)) if swing > 0 else 0
                                rysuj_piksele(y_ng_s, y_bt_s - skroc, (40, 45, 65))
                        else: 
                            if 0.34 <= rel_x <= 0.66:
                                strona_twarzy = (strona == 'LEFT' and rel_x < 0.50) or (strona == 'RIGHT' and rel_x > 0.50)
                                if strona_twarzy:
                                    rysuj_piksele(y_gl_s, y_gl_s + int(h_glowy * 0.20), (35, 25, 20))
                                    rysuj_piksele(y_gl_s + int(h_glowy * 0.20), y_gl_e, (215, 150, 120))
                                else:
                                    rysuj_piksele(y_gl_s, y_gl_e, (35, 25, 20))
                            if 0.24 <= rel_x <= 0.76:
                                rysuj_piksele(y_tl_s, y_tl_e, (55, 65, 60))
                            if 0.34 <= rel_x <= 0.66:
                                rysuj_piksele(y_ng_s, y_bt_s, (40, 45, 65))
                                rysuj_piksele(y_bt_s, y_bt_e, (20, 20, 22))

                # Billboard tekstu Nicku nad modelem postaci (rysujemy po wyjściu z pętli promieni)
                ray_srodek = screen_x // SCALE
                if 0 <= ray_srodek < NUM_RAYS and dystans_kor < z_buffer[ray_srodek] + 20:
                    txt_tag = self.font_small.render(d['nick'], True, (int(220*wsp_sw_kumpla), int(220*wsp_sw_kumpla), int(220*wsp_sw_kumpla)))
                    self.ekran.blit(txt_tag, (screen_x - txt_tag.get_width() // 2, player_top - 30))

    # --- OBSŁUGA INTERFEJSU I PĘTLI GRY ---

    def zablokuj_mysz_gry(self):
        self.mysz_zablokowana = True
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
        pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
        self.mysz_zainicjalizowana = False

    def obsluga_zdarzen(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.dziala = False
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if self.rola == 'wpisywanie_nicku':
                    if event.key == pygame.K_RETURN:
                        if self.moj_nick.strip():
                            self.rola = 'menu'
                    elif event.key == pygame.K_BACKSPACE:
                        self.moj_nick = self.moj_nick[:-1]
                    else:
                        if len(self.moj_nick) < 14 and (event.unicode.isalnum() or event.unicode in [' ', '_', '-']):
                            self.moj_nick += event.unicode

                elif self.rola in ['solo', 'serwer', 'klient']:
                    if event.key == pygame.K_ESCAPE:
                        self.mysz_zablokowana = not self.mysz_zablokowana
                        pygame.mouse.set_visible(not self.mysz_zablokowana)
                        pygame.event.set_grab(self.mysz_zablokowana)
                    if event.key == pygame.K_f:
                        if self.bateria > 0:
                            self.latarka_wlaczona = not self.latarka_wlaczona

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = pygame.mouse.get_pos()
                if self.rola == 'menu':
                    if self.btn_single.collidepoint(pos):
                        self.rola = 'solo'
                        self.generuj_mape()
                        self.zablokuj_mysz_gry()
                    elif self.btn_host.collidepoint(pos):
                        self.rola = 'serwer'
                        self.generuj_mape()
                        self.zablokuj_mysz_gry()
                        threading.Thread(target=self.nadawaj_obecnosc, daemon=True).start()
                        threading.Thread(target=self.odpal_serwer_sieciowy, daemon=True).start()
                    else:
                        for rect, ip, port in self.serwery_przyciski:
                            if rect.collidepoint(pos):
                                self.wykryty_serwery.clear()
                                self.wybrany_serwer_ip = ip
                                self.wybrany_serwer_port = port
                                self.rola = 'klient'
                                self.generuj_mape()
                                self.zablokuj_mysz_gry()
                                threading.Thread(target=self.odpal_klienta_sieciowy, daemon=True).start()
                                break
                elif self.rola in ['solo', 'serwer', 'klient'] and not self.mysz_zablokowana:
                    self.zablokuj_mysz_gry()

    def aktualizacja(self):
        if self.rola not in ['solo', 'serwer', 'klient']:
            return

        # 1. Obrót kamery myszą (Kąt YAW oraz PITCH)
        if self.mysz_zablokowana:
            mx, my = pygame.mouse.get_pos()
            if not self.mysz_zainicjalizowana:
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
                self.mysz_zainicjalizowana = True
            else:
                dx = mx - SZEROKOSC // 2
                dy = my - WYSOKOSC // 2
                self.moje_kat += dx * self.czulosc_myszy
                self.moje_pitch -= dy * 1.2
                self.moje_pitch = max(-260, min(260, self.moje_pitch))
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)

        # 2. Translacja ruchu gracza (WSAD)
        klawisze = pygame.key.get_pressed()
        dx_ruch, dy_ruch = 0.0, 0.0
        cos_a = math.cos(self.moje_kat)
        sin_a = math.sin(self.moje_kat)

        idzie = False
        if klawisze[pygame.K_w]:
            dx_ruch += cos_a
            dy_ruch += sin_a
            idzie = True
        if klawisze[pygame.K_s]:
            dx_ruch -= cos_a
            dy_ruch -= sin_a
            idzie = True
        if klawisze[pygame.K_a]:
            dx_ruch += sin_a
            dy_ruch -= cos_a
            idzie = True
        if klawisze[pygame.K_d]:
            dx_ruch -= sin_a
            dy_ruch += cos_a
            idzie = True

        self.idzie_teraz = idzie

        if idzie:
            dlugosc = math.hypot(dx_ruch, dy_ruch)
            dx_ruch = (dx_ruch / dlugosc) * self.predkosc_ruchu
            dy_ruch = (dy_ruch / dlugosc) * self.predkosc_ruchu
            self.ruch_i_kolizje(dx_ruch, dy_ruch)

            # View Bobbing
            self.licznik_chodzenia += 0.22
            self.bujanie_glowy_y = math.sin(self.licznik_chodzenia) * 5.0
        else:
            self.bujanie_glowy_y *= 0.75

        # 3. Rozładowywanie latarki
        if self.latarka_wlaczona:
            self.bateria -= 0.04
            if self.bateria <= 0:
                self.bateria = 0
                self.latarka_wlaczona = False
        else:
            if self.bateria < self.max_bateria:
                self.bateria += 0.015

    def rysuj_ui(self):
        if self.rola == 'wpisywanie_nicku':
            self.ekran.fill((10, 10, 15))
            txt_t = self.font_big.render("NO SIGNAL: 3D HORROR", True, (210, 20, 20))
            self.ekran.blit(txt_t, (SZEROKOSC // 2 - txt_t.get_width() // 2, 220))
            
            txt_p = self.font_main.render("Wpisz swój nick i naciśnij ENTER:", True, KOLOR_UI)
            self.ekran.blit(txt_p, (SZEROKOSC // 2 - txt_p.get_width() // 2, 420))
            
            txt_n = self.font_big.render(self.moj_nick + "_", True, (240, 240, 250))
            self.ekran.blit(txt_n, (SZEROKOSC // 2 - txt_n.get_width() // 2, 500))

        elif self.rola == 'menu':
            self.ekran.fill((15, 15, 20))
            txt_t = self.font_big.render("POKÓJ LAN MULTIPLAYER", True, KOLOR_UI)
            self.ekran.blit(txt_t, (100, 100))

            # Przycisk Singleplayer
            pygame.draw.rect(self.ekran, KOLOR_BTN, self.btn_single)
            txt_s = self.font_main.render("Graj Samotnie (Single)", True, KOLOR_UI)
            self.ekran.blit(txt_s, (self.btn_single.x + 20, self.btn_single.y + 12))

            # Przycisk Hostowania
            pygame.draw.rect(self.ekran, KOLOR_BTN, self.btn_host)
            txt_h = self.font_main.render("Zostań Hostem (Stwórz serwer)", True, KOLOR_UI)
            self.ekran.blit(txt_h, (self.btn_host.x + 20, self.btn_host.y + 12))

            txt_l = self.font_main.render("Wykryte serwery w sieci LAN (Kliknij, by wejść):", True, (160, 160, 170))
            self.ekran.blit(txt_l, (100, 430))

            self.serwery_przyciski = []
            y_offset = 490
            for name, (ip, port, _) in self.wykryte_serwery.items():
                rect = pygame.Rect(100, y_offset, 650, 50)
                self.serwery_przyciski.append((rect, ip, port))
                pygame.draw.rect(self.ekran, (35, 50, 40), rect)
                srv_txt = self.font_small.render(f"{name} -> {ip}:{port}", True, (180, 240, 180))
                self.ekran.blit(srv_txt, (rect.x + 15, rect.y + 12))
                y_offset += 60
                if y_offset > WYSOKOSC - 80: break

            if not self.wykryte_serwery:
                txt_n = self.font_small.render("Skanowanie sieci w poszukiwaniu gier...", True, (110, 110, 115))
                self.ekran.blit(txt_n, (100, 490))

        elif self.rola in ['solo', 'serwer', 'klient']:
            # Celownik na środku ekranu
            pygame.draw.circle(self.ekran, (255, 255, 255), (SZEROKOSC // 2, WYSOKOSC // 2), 2)

            # Panel interfejsu baterii
            pygame.draw.rect(self.ekran, (40, 40, 45), (30, 30, 200, 24))
            szer_bat = int(200 * (self.bateria / self.max_bateria))
            kolor_b = (40, 210, 80) if self.bateria > 25 else (210, 40, 40)
            if szer_bat > 0:
                pygame.draw.rect(self.ekran, kolor_b, (30, 30, szer_bat, 24))
            txt_b = self.font_small.render(f"ZASILANIE: {int(self.bateria)}%", True, KOLOR_UI)
            self.ekran.blit(txt_b, (245, 30))

            # Status sesji
            status = f"Tryb: {self.rola.upper()} | Gracz: {self.moj_nick}"
            if self.rola == 'serwer':
                status += f" | Połączeń: {len(self.klienci)}"
            elif self.rola == 'klient':
                status += " | Połączono z hostem"
            txt_st = self.font_small.render(status, True, (140, 140, 145))
            self.ekran.blit(txt_st, (30, WYSOKOSC - 45))

            txt_i = self.font_small.render("ESC: menu myszy | F: latarka", True, (110, 110, 115))
            self.ekran.blit(txt_i, (SZEROKOSC - txt_i.get_width() - 30, WYSOKOSC - 45))

    def uruchom(self):
        # Aktywacja wątku odbierania pakietów rozgłoszeniowych serwerów
        threading.Thread(target=self.sluchaj_obecnosci, daemon=True).start()
        
        while self.dziala:
            self.obsluga_zdarzen()
            self.aktualizacja()
            
            if self.rola in ['solo', 'serwer', 'klient']:
                self.rysuj_scene_3d()
            self.rysuj_ui()
            
            pygame.display.flip()
            self.zegar.tick(FPS)

if __name__ == "__main__":
    gra = GraHorror3D()
    gra.uruchom()
