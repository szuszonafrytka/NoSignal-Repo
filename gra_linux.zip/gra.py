"""
main.py - No Signal: 3D Horror Game [EMF UI VISIBILITY FIX]
Zaimplementowano:
1. Widoczny panel EMF przeniesiony do lewego górnego rogu (pod poziom) z ramką HUD i opisem statusu.
2. Dynamiczne pikanie dźwiękowe i miganie diody zależne od dystansu do celu.
3. Pełny mrok bez latarki oraz szeroki snop światła po jej włączeniu.
Ścieżka skryptu: main.py
"""

import pygame
import sys
import math
import random

# --- KONFIGURACJA GLOBALNA ---
WERSJA = "8.9_EMF_HUD_Fix"
SZEROKOSC, WYSOKOSC = 1280, 960
FPS = 60
ROZMIAR_BLOKU = 64  

KOLOR_UI = (255, 255, 255)
KOLOR_BTN = (40, 40, 50)

FOV = math.pi / 3  
HALF_FOV = FOV / 2
NUM_RAYS = 320  
MAX_DEPTH = 800  
SCREEN_DIST = (SZEROKOSC / 2) / math.tan(HALF_FOV)
PROJ_COEFF = ROZMIAR_BLOKU * SCREEN_DIST
SCALE = SZEROKOSC // NUM_RAYS

LAB_SZEROKOSC = 41
LAB_WYSOKOSC = 41

class GraHorror3D:
    def __init__(self):
        pygame.init()
        # Inicjalizacja miksera audio dla systemowego dźwięku EMF
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
        except:
            pass
            
        self.ekran = pygame.display.set_mode((SZEROKOSC, WYSOKOSC))
        pygame.display.set_caption(f"No Signal 3D - EMF HUD Edition (v{WERSJA})")
        self.zegar = pygame.time.Clock()

        self.dziala = True
        self.stan_menu = 'wpisywanie_nicku'  
        self.aktualny_poziom = 1
        
        self.latarka_wlaczona = True
        self.mysz_zainicjalizowana = False
        self.mysz_zablokowana = True  

        self.moje_x = 96.0
        self.moje_y = 96.0
        self.moje_kat = 0.0  
        self.moje_pitch = 0.0  
        self.predkosc_ruchu = 3.5  
        self.czulosc_myszy = 0.0025
        self.idzie_teraz = False  

        self.licznik_chodzenia = 0.0
        self.bujanie_glowy_y = 0.0
        self.bateria = 100.0
        self.max_bateria = 100.0

        # --- ZMIENNE DETEKTORA EMF ---
        self.emf_timer = 0
        self.emf_dioda_swieci = False
        self.emf_dystans = 999.0

        self.moj_nick = "Gracz"
        
        self.przedmioty = [] 
        self.zebrane_klucze = 0
        self.wymagane_klucze = 1
        
        self.drzwi_kafelki = set()
        self.mapa_struktura = []
        
        self.font_main = pygame.font.SysFont("Arial", 32)
        self.font_small = pygame.font.SysFont("Arial", 24)
        self.font_big = pygame.font.SysFont("Arial", 40)

        self.btn_single = pygame.Rect(100, 200, 500, 60)
        
        self.tekstura_sciany = self.generuj_powierzchnie_realistycznej_sciany()
        self.tekstura_drzwi = self.generuj_powierzchnie_drzwi()

    def generuj_powierzchnie_realistycznej_sciany(self):
        powierzchnia = pygame.Surface((ROZMIAR_BLOKU, ROZMIAR_BLOKU))
        powierzchnia.fill((50, 46, 48)) 
        
        for y in range(ROZMIAR_BLOKU):
            przesuniecie_bloku = 24 if (y // 14) % 2 == 0 else 0
            for x in range(ROZMIAR_BLOKU):
                jest_fuga_h = abs((y % 14) - 0) <= 1 or (y == ROZMIAR_BLOKU - 1)
                jest_fuga_v = abs(((x + przesuniecie_bloku) % 28) - 0) <= 1 or (x == ROZMIAR_BLOKU - 1)
                
                if jest_fuga_h or jest_fuga_v:
                    szum_fugi = random.randint(-3, 3)
                    r = max(15, min(32, 22 + szum_fugi))
                    powierzchnia.set_at((x, y), (r, r, r + 2))
                else:
                    szum_struktury = int(math.sin(x * 0.4) * 6 + math.cos(y * 0.4) * 6)
                    szum_losowy = random.randint(-5, 5)
                    
                    r = max(40, min(100, 68 + szum_struktury + szum_losowy))
                    g = max(40, min(100, 62 + szum_struktury + szum_losowy))
                    b = max(40, min(105, 60 + szum_struktury + szum_losowy))
                    
                    if (x * y) % 31 == 0:
                        r, g, b = int(r * 0.7), int(g * 0.7), int(b * 0.7)
                        
                    powierzchnia.set_at((x, y), (r, g, b))

        powierzchnia_smooth = powierzchnia.copy()
        for y in range(1, ROZMIAR_BLOKU - 1):
            for x in range(1, ROZMIAR_BLOKU - 1):
                c1 = powierzchnia.get_at((x - 1, y))
                c2 = powierzchnia.get_at((x, y))
                c3 = powierzchnia.get_at((x + 1, y))
                nr = (c1[0] + c2[0] + c3[0]) // 3
                ng = (c1[1] + c2[1] + c3[1]) // 3
                nb = (c1[2] + c2[2] + c3[2]) // 3
                powierzchnia_smooth.set_at((x, y), (nr, ng, nb))

        return powierzchnia_smooth

    def generuj_powierzchnie_drzwi(self):
        powierzchnia = pygame.Surface((ROZMIAR_BLOKU, ROZMIAR_BLOKU))
        powierzchnia.fill((85, 48, 28)) 
        for y in range(ROZMIAR_BLOKU):
            for x in range(ROZMIAR_BLOKU):
                szum = random.randint(-4, 4)
                if x % 16 <= 1 or x == ROZMIAR_BLOKU - 1 or y % 32 <= 1:
                    powierzchnia.set_at((x, y), (38, 22, 12)) 
                else:
                    powierzchnia.set_at((x, y), (max(0, 78+szum), max(0, 44+szum), max(0, 24+szum)))
        return powierzchnia

    def konfiguruj_poziom(self):
        if self.aktualny_poziom == 1:
            self.wymagane_klucze = 1
            liczba_baterii = 2
        elif self.aktualny_poziom == 2:
            self.wymagane_klucze = 2
            liczba_baterii = 4
        else:
            self.wymagane_klucze = 3
            liczba_baterii = 5
            
        self.zebrane_klucze = 0
        self.przedmioty.clear()
        self.generuj_labirynt(liczba_baterii)

    def generuj_labirynt(self, liczba_baterii):
        szer, wys = LAB_SZEROKOSC, LAB_WYSOKOSC
        self.mapa_struktura = [[1 for _ in range(szer)] for _ in range(wys)]
        self.drzwi_kafelki.clear()

        odwiedzone = set()
        stos = [(1, 1)]
        self.mapa_struktura[1][1] = 0
        odwiedzone.add((1, 1))

        while stos:
            cx, cy = stos[-1]
            sasiedzi = []
            
            kierunki = [(0, -2), (2, 0), (0, 2), (-2, 0)]
            for dx, dy in kierunki:
                nx, ny = cx + dx, cy + dy
                if 0 < nx < szer - 1 and 0 < ny < wys - 1:
                    if (nx, ny) not in odwiedzone:
                        sasiedzi.append((nx, ny, dx // 2, dy // 2))
            
            if sasiedzi:
                nx, ny, d_x, d_y = random.choice(sasiedzi)
                self.mapa_struktura[cy + d_y][cx + d_x] = 0
                self.mapa_struktura[ny][nx] = 0
                
                odwiedzone.add((nx, ny))
                stos.append((nx, ny))
            else:
                stos.pop()

        for _ in range((szer * wys) // 10):
            rx = random.randint(2, szer - 3)
            ry = random.randint(2, wys - 3)
            if self.mapa_struktura[ry][rx] == 1:
                if self.mapa_struktura[ry-1][rx] == 0 and self.mapa_struktura[ry+1][rx] == 0:
                    self.mapa_struktura[ry][rx] = 0
                elif self.mapa_struktura[ry][rx-1] == 0 and self.mapa_struktura[ry][rx+1] == 0:
                    self.mapa_struktura[ry][rx] = 0

        wolne_punkty = []
        for y in range(1, wys - 1):
            for x in range(1, szer - 1):
                if self.mapa_struktura[y][x] == 0 and (x > 4 or y > 4):
                    wolne_punkty.append((x, y))

        if len(wolne_punkty) < (self.wymagane_klucze + liczba_baterii + 1):
            wolne_punkty = [(szer - 2, wys - 2), (szer - 2, wys - 3), (szer - 3, wys - 2), (szer - 3, wys - 3)]
        
        random.shuffle(wolne_punkty)

        kolory_kluczy = [(255, 215, 0), (240, 40, 40), (40, 220, 40)] 
        for i in range(self.wymagane_klucze):
            if wolne_punkty:
                kx, ky = wolne_punkty.pop()
                px = kx * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
                py = ky * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
                self.przedmioty.append({
                    'x': px, 'y': py, 'typ': 'klucz', 'kolor': kolory_kluczy[i], 
                    'nazwa': "ZŁOTY" if i==0 else ("CZERWONY" if i==1 else "ZIELONY")
                })

        for _ in range(liczba_baterii):
            if wolne_punkty:
                bx, by = wolne_punkty.pop()
                px = bx * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
                py = by * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
                self.przedmioty.append({
                    'x': px, 'y': py, 'typ': 'bateria', 'kolor': (30, 144, 255), 'nazwa': "NIEBIESKĄ BATERIĘ"
                })

        if wolne_punkty:
            dx, dy = wolne_punkty.pop()
            self.mapa_struktura[dy][dx] = 2
            self.drzwi_kafelki.add((dx, dy))

        self.moje_x = 1 * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
        self.moje_y = 1 * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
        self.moje_kat = 0.0
        self.moje_pitch = 0.0

    def ruch_i_kolizje(self, dx, dy):
        PROMIEN_GRACZA = 15  
        
        nowe_x = self.moje_x + dx
        margines_x = PROMIEN_GRACZA if dx > 0 else -PROMIEN_GRACZA
        map_x = int((nowe_x + margines_x) // ROZMIAR_BLOKU)
        map_y = int(self.moje_y // ROZMIAR_BLOKU)
        
        if 0 <= map_x < LAB_SZEROKOSC and 0 <= map_y < LAB_WYSOKOSC:
            if self.mapa_struktura[map_y][map_x] in [0, 2]:
                self.moje_x = nowe_x

        nowe_y = self.moje_y + dy
        margines_y = PROMIEN_GRACZA if dy > 0 else -PROMIEN_GRACZA
        map_x = int(self.moje_x // ROZMIAR_BLOKU)
        map_y = int((nowe_y + margines_y) // ROZMIAR_BLOKU)
        
        if 0 <= map_x < LAB_SZEROKOSC and 0 <= map_y < LAB_WYSOKOSC:
            if self.mapa_struktura[map_y][map_x] in [0, 2]:
                self.moje_y = nowe_y

        curr_x = int(self.moje_x // ROZMIAR_BLOKU)
        curr_y = int(self.moje_y // ROZMIAR_BLOKU)
        if (curr_x, curr_y) in self.drzwi_kafelki and self.zebrane_klucze == self.wymagane_klucze:
            if self.aktualny_poziom < 3:
                self.aktualny_poziom += 1
                self.konfiguruj_poziom()
            else:
                self.stan_menu = 'glowne_menu'
                self.mysz_zablokowana = False
                pygame.mouse.set_visible(True)
                pygame.event.set_grab(False)

    def rysuj_scene_3d(self):
        self.ekran.fill((0, 0, 0)) 
        
        centr_y = WYSOKOSC // 2 + self.moje_pitch + self.bujanie_glowy_y
        z_buffer = [MAX_DEPTH] * NUM_RAYS
        kat_startowy = self.moje_kat - HALF_FOV

        for ray in range(NUM_RAYS):
            kat_promienia = kat_startowy + ray * (FOV / NUM_RAYS)
            sin_a = math.sin(kat_promienia)
            cos_a = math.cos(kat_promienia)

            for glebokosc in range(1, MAX_DEPTH, 1): 
                cel_x = self.moje_x + glebokosc * cos_a
                cel_y = self.moje_y + glebokosc * sin_a

                b_x = int(cel_x // ROZMIAR_BLOKU)
                b_y = int(cel_y // ROZMIAR_BLOKU)

                if 0 <= b_x < LAB_SZEROKOSC and 0 <= b_y < LAB_WYSOKOSC:
                    typ_bloku = self.mapa_struktura[b_y][b_x]
                    
                    if typ_bloku in [1, 2]:
                        glebokosc_kor = glebokosc * math.cos(kat_promienia - self.moje_kat)
                        glebokosc_kor = max(glebokosc_kor, 0.0001)
                        z_buffer[ray] = glebokosc_kor
                        
                        if self.latarka_wlaczona:
                            MAX_WIDOCZNOSC = 650
                            ST_LATARKI = HALF_FOV * 1.1
                            
                            spadek_odleglosci = max(0.0, 1.0 - (glebokosc / MAX_WIDOCZNOSC))
                            roznica_srodka = (kat_promienia - self.moje_kat + math.pi) % (2 * math.pi) - math.pi
                            
                            if abs(roznica_srodka) < ST_LATARKI:
                                spadek_kata = (1.0 - (abs(roznica_srodka) / ST_LATARKI)) ** 2
                                latarka_moc = spadek_odleglosci * spadek_kata
                            else:
                                latarka_moc = 0.0
                                
                            ambient = max(0.02, 1.0 - (glebokosc / 250)) * 0.15
                            wsp_swiatla = max(ambient, latarka_moc)
                        else:
                            wsp_swiatla = max(0.0, 1.0 - (glebokosc / 130)) * 0.3
                            if wsp_swiatla <= 0.005:
                                break  

                        wsp_swiatla = max(0.0, min(1.0, wsp_swiatla))

                        wysokosc_sciany = int(PROJ_COEFF / glebokosc_kor)
                        wall_top = centr_y - wysokosc_sciany // 2

                        hit_x = cel_x % ROZMIAR_BLOKU
                        hit_y = cel_y % ROZMIAR_BLOKU
                        if abs(hit_x - 0) < 2 or abs(hit_x - (ROZMIAR_BLOKU-1)) < 2:
                            tex_x = int(hit_y)
                        else:
                            tex_x = int(hit_x)
                        tex_x = max(0, min(ROZMIAR_BLOKU - 1, tex_x))

                        tekstura_zrodlowa = self.tekstura_sciany if typ_bloku == 1 else self.tekstura_drzwi
                        
                        pasek = pygame.Surface((1, ROZMIAR_BLOKU))
                        pasek.blit(tekstura_zrodlowa, (0, 0), (tex_x, 0, 1, ROZMIAR_BLOKU))
                        
                        wysokosc_sciany = max(1, wysokosc_sciany)
                        skalowany_pasek = pygame.transform.scale(pasek, (SCALE, wysokosc_sciany))
                        
                        cień = pygame.Surface(skalowany_pasek.get_size(), pygame.SRCALPHA)
                        wartosc_alphy = int((1.0 - wsp_swiatla) * 255)
                        cień.fill((0, 0, 0, wartosc_alphy))
                        
                        skalowany_pasek.blit(cień, (0, 0))
                        self.ekran.blit(skalowany_pasek, (ray * SCALE, wall_top))
                        break

        # --- TRÓJWYMIAROWE PRZEDMIOTY ---
        for obj in self.przedmioty:
            dx = obj['x'] - self.moje_x
            dy = obj['y'] - self.moje_y
            dystans = math.hypot(dx, dy)

            theta = math.atan2(dy, dx)
            gamma = theta - self.moje_kat
            gamma = (gamma + math.pi) % (2 * math.pi) - math.pi  

            if -HALF_FOV < gamma < HALF_FOV and dystans > 5:
                dystans_kor = max(dystans * math.cos(gamma), 0.0001)
                limit_widzenia = MAX_DEPTH if self.latarka_wlaczona else 130
                
                if dystans_kor < limit_widzenia:
                    screen_x = int((SZEROKOSC / 2) + math.tan(gamma) * SCREEN_DIST)
                    wysokosc_sciany = int(PROJ_COEFF / dystans_kor)
                    
                    if obj['typ'] == 'klucz':
                        obj_h = int(wysokosc_sciany * 0.4)
                        obj_w = max(3, int(obj_h * 0.25))
                    else: 
                        obj_h = int(wysokosc_sciany * 0.25)
                        obj_w = max(4, int(obj_h * 0.5))
                        
                    center_y_obj = centr_y + int(wysokosc_sciany * 0.18)
                    obj_top = center_y_obj - obj_h // 2
                    
                    ray_idx = screen_x // SCALE
                    if 0 <= ray_idx < NUM_RAYS and dystans_kor < z_buffer[ray_idx]:
                        wsp_k = max(0.1, 1.0 - (dystans_kor / 450)) if self.latarka_wlaczona else max(0.0, 1.0 - (dystans_kor / 110)) * 0.4
                        if wsp_k > 0.02:
                            r = int(obj['kolor'][0] * wsp_k)
                            g = int(obj['kolor'][1] * wsp_k)
                            b = int(obj['kolor'][2] * wsp_k)
                            pygame.draw.rect(self.ekran, (r, g, b), (screen_x - obj_w // 2, obj_top, obj_w, obj_h))

        # --- UI GRY (LEWA STRONA) ---
        pygame.draw.circle(self.ekran, (140, 140, 140), (SZEROKOSC // 2, WYSOKOSC // 2), 2)

        # Wskaźnik baterii
        pygame.draw.rect(self.ekran, (30, 30, 30), (20, 20, 200, 25))
        kolor_baterii = (30, 144, 255) if self.latarka_wlaczona else (100, 100, 100)
        if self.bateria < 20 and self.latarka_wlaczona: kolor_baterii = (220, 40, 40)
        pygame.draw.rect(self.ekran, kolor_baterii, (20, 20, int(self.bateria * 2), 25))
        
        # Tekst poziomu
        txt_lvl = self.font_small.render(f"POZIOM: {self.aktualny_poziom}/3", True, (255, 255, 255))
        self.ekran.blit(txt_lvl, (20, 55))

        # Stan kluczy (góra-środek)
        status_tekst = f"KLUCZE: {self.zebrane_klucze} / {self.wymagane_klucze}"
        kolor_statusu = (235, 210, 40) if self.zebrane_klucze < self.wymagane_klucze else (40, 235, 90)
        txt_status = self.font_small.render(status_tekst, True, kolor_statusu)
        self.ekran.blit(txt_status, (250, 18))

        # --- NOWY, BARDZO WIDOCZNY PANEL DETEKTORA EMF (TUTAJ PRZENIESIONY) ---
        # Tworzymy ciemne tło z obwódką dla panelu w widocznym miejscu po lewej pod poziomem
        pygame.draw.rect(self.ekran, (20, 20, 25), (20, 90, 240, 42))
        pygame.draw.rect(self.ekran, (70, 70, 85), (20, 90, 240, 42), 1)
        
        txt_emf_title = self.font_small.render("EMF:", True, (200, 200, 200))
        self.ekran.blit(txt_emf_title, (30, 98))
        
        # Ustalenie stanu detektora na bazie wyliczonego dystansu
        if self.emf_dystans > 400:
            opis_stanu = "NISKI"
            kolor_dioda = (160, 20, 20) if self.emf_dioda_swieci else (40, 5, 5)
        elif self.emf_dystans > 150:
            opis_stanu = "ZBLIŻANIE"
            kolor_dioda = (240, 180, 20) if self.emf_dioda_swieci else (60, 45, 5)
        else:
            opis_stanu = "BLISKO!"
            kolor_dioda = (30, 250, 60) if self.emf_dioda_swieci else (5, 60, 10)
            
        # Wyświetlanie napisu stanu
        txt_stan_emf = self.font_small.render(opis_stanu, True, kolor_dioda if self.emf_dioda_swieci else (120, 120, 120))
        self.ekran.blit(txt_stan_emf, (85, 98))
        
        # Świecąca fizycznie dioda kołowa wewnątrz panelu
        pygame.draw.circle(self.ekran, kolor_dioda, (235, 111), 10)
        pygame.draw.circle(self.ekran, (200, 200, 200), (235, 111), 10, 2)

        # Interakcja podnoszenia
        najblizszy_obj = None
        min_dst = 55.0
        for obj in self.przedmioty:
            dst = math.hypot(obj['x'] - self.moje_x, obj['y'] - self.moje_y)
            if dst < min_dst:
                min_dst = dst
                najblizszy_obj = obj

        if najblizszy_obj:
            txt_action = self.font_main.render(f"Naciśnij [F], aby podnieść {najblizszy_obj['nazwa']}", True, (255, 255, 100))
            self.ekran.blit(txt_action, (SZEROKOSC // 2 - txt_action.get_width() // 2, WYSOKOSC - 150))

    def zablokuj_mysz_gry(self):
        self.mysz_zablokowana = True
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
        pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
        self.mysz_zainicjalizowana = False

    def obsluga_zdarzen(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.dziala = False
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if self.stan_menu == 'wpisywanie_nicku':
                    if event.key == pygame.K_RETURN and self.moj_nick.strip():
                        self.stan_menu = 'glowne_menu'
                    elif event.key == pygame.K_BACKSPACE: self.moj_nick = self.moj_nick[:-1]
                    else:
                        if len(self.moj_nick) < 14 and (event.unicode.isalnum() or event.unicode in [' ', '_', '-']):
                            self.moj_nick += event.unicode

                elif self.stan_menu == 'gra':
                    if event.key == pygame.K_ESCAPE:
                        self.mysz_zablokowana = not self.mysz_zablokowana
                        pygame.mouse.set_visible(not self.mysz_zablokowana)
                        pygame.event.set_grab(self.mysz_zablokowana)
                    
                    if event.key == pygame.K_f:
                        najblizszy_idx = -1
                        min_dst = 55.0
                        for idx, obj in enumerate(self.przedmioty):
                            dst = math.hypot(obj['x'] - self.moje_x, obj['y'] - self.moje_y)
                            if dst < min_dst:
                                min_dst = dst
                                najblizszy_idx = idx

                        if najblizszy_idx != -1:
                            obj = self.przedmioty.pop(najblizszy_idx)
                            if obj['typ'] == 'klucz':
                                self.zebrane_klucze += 1
                            elif obj['typ'] == 'bateria':
                                self.bateria = min(self.max_bateria, self.bateria + 35.0) 
                        else:
                            if self.bateria > 0:
                                self.latarka_wlaczona = not self.latarka_wlaczona

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = pygame.mouse.get_pos()
                
                if self.stan_menu == 'glowne_menu':
                    if self.btn_single.collidepoint(pos):
                        self.aktualny_poziom = 1
                        self.konfiguruj_poziom()
                        self.stan_menu = 'gra'
                        self.zablokuj_mysz_gry()

                elif self.stan_menu == 'gra' and not self.mysz_zablokowana:
                    self.zablokuj_mysz_gry()

    def aktualizacja(self):
        if self.stan_menu != 'gra': return

        if self.mysz_zablokowana:
            mx, my = pygame.mouse.get_pos()
            if not self.mysz_zainicjalizowana:
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
                self.mysz_zainicjalizowana = True
            else:
                self.moje_kat += (mx - SZEROKOSC // 2) * self.czulosc_myszy
                self.moje_pitch = max(-260, min(260, self.moje_pitch - (my - WYSOKOSC // 2) * 1.2))
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)

        klawisze = pygame.key.get_pressed()
        dx, dy = 0.0, 0.0
        cos_a, sin_a = math.cos(self.moje_kat), math.sin(self.moje_kat)

        idzie = False
        if klawisze[pygame.K_w]: dx += cos_a; dy += sin_a; idzie = True
        if klawisze[pygame.K_s]: dx -= cos_a; dy -= sin_a; idzie = True
        if klawisze[pygame.K_a]: dx += sin_a; dy -= cos_a; idzie = True
        if klawisze[pygame.K_d]: dx -= sin_a; dy += cos_a; idzie = True

        self.idzie_teraz = idzie

        if idzie:
            dl = math.hypot(dx, dy)
            self.ruch_i_kolizje((dx / dl) * self.predkosc_ruchu, (dy / dl) * self.predkosc_ruchu)
            self.licznik_chodzenia += 0.22
            self.bujanie_glowy_y = math.sin(self.licznik_chodzenia) * 5.0
        else:
            self.bujanie_glowy_y *= 0.75

        if self.latarka_wlaczona:
            mnoznik_zuzycia = 1.0
            if self.aktualny_poziom == 2: mnoznik_zuzycia = 1.4
            elif self.aktualny_poziom == 3: mnoznik_zuzycia = 2.0
            
            self.bateria = max(0, self.bateria - (0.025 * mnoznik_zuzycia))
            if self.bateria == 0: self.latarka_wlaczona = False
        else: 
            mnoznik_reg = 1.0 if self.aktualny_poziom == 1 else 0.5
            self.bateria = min(self.max_bateria, self.bateria + (0.015 * mnoznik_reg))

        # --- SYSTEM EMF RADAR ---
        bliski_cel_dist = 9999.0
        if self.zebrane_klucze < self.wymagane_klucze:
            for obj in self.przedmioty:
                if obj['typ'] == 'klucz':
                    d = math.hypot(obj['x'] - self.moje_x, obj['y'] - self.moje_y)
                    if d < bliski_cel_dist: bliski_cel_dist = d
        else:
            for dx_kafelek, dy_kafelek in self.drzwi_kafelki:
                drzwi_x = dx_kafelek * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
                drzwi_y = dy_kafelek * ROZMIAR_BLOKU + ROZMIAR_BLOKU // 2
                d = math.hypot(drzwi_x - self.moje_x, drzwi_y - self.moje_y)
                if d < bliski_cel_dist: bliski_cel_dist = d

        self.emf_dystans = bliski_cel_dist

        if self.emf_dystans > 400: interwal = 45  
        elif self.emf_dystans > 150: interwal = 20  
        else: interwal = 6   

        self.emf_timer += 1
        if self.emf_timer >= interwal:
            self.emf_timer = 0
            self.emf_dioda_swieci = not self.emf_dioda_swieci
            
            if self.emf_dioda_swieci:
                try:
                    czestotliwosc_dzwieku = 800 if self.emf_dystans < 150 else (500 if self.emf_dystans < 400 else 350)
                    duration = 0.04
                    sample_rate = 22050
                    n_samples = int(duration * sample_rate)
                    buf = bytearray()
                    for i in range(n_samples):
                        t = float(i) / sample_rate
                        val = int(math.sin(2.0 * math.pi * czestotliwosc_dzwieku * t) * 10000)
                        buf.extend(val.to_bytes(2, byteorder='little', signed=True))
                    sound = pygame.mixer.Sound(buffer=buf)
                    sound.set_volume(0.15)
                    sound.play()
                except:
                    pass

    def rysuj_ui(self):
        self.ekran.fill((15, 15, 20))
        
        if self.stan_menu == 'wpisywanie_nicku':
            txt_t = self.font_big.render("NO SIGNAL: 3D HORROR", True, (210, 20, 20))
            self.ekran.blit(txt_t, (SZEROKOSC // 2 - txt_t.get_width() // 2, 220))
            txt_p = self.font_main.render("Wpisz swój nick i naciśnij ENTER:", True, KOLOR_UI)
            self.ekran.blit(txt_p, (SZEROKOSC // 2 - txt_p.get_width() // 2, 420))
            txt_n = self.font_big.render(self.moj_nick + "_", True, (240, 240, 250))
            self.ekran.blit(txt_n, (SZEROKOSC // 2 - txt_n.get_width() // 2, 500))

        elif self.stan_menu == 'glowne_menu':
            txt_t = self.font_big.render(f"Witaj, {self.moj_nick}! Wybierz tryb:", True, KOLOR_UI)
            self.ekran.blit(txt_t, (100, 100))

            pygame.draw.rect(self.ekran, KOLOR_BTN, self.btn_single)
            self.ekran.blit(self.font_main.render("URUCHOM PROGRESYWNĄ KAMPANIĘ", True, KOLOR_UI), (self.btn_single.x + 15, self.btn_single.y + 12))

            txt_desc = self.font_small.render("Cel: Zbierz wymaganą liczbę kluczy na każdym poziomie i uciekaj przez brązowe drzwi.", True, (160, 160, 170))
            self.ekran.blit(txt_desc, (100, 320))
            txt_desc2 = self.font_small.render("Zbieraj NIEBIESKIE BATERIE [F], aby podładować szybko gasnącą latarkę!", True, (30, 144, 255))
            self.ekran.blit(txt_desc2, (100, 360))
            txt_desc3 = self.font_small.render("NOWOŚĆ: Obserwuj i słuchaj czujnika EMF pod wskaźnikiem poziomu, by namierzać cele w mroku!", True, (20, 240, 50))
            self.ekran.blit(txt_desc3, (100, 400))

    def run(self):
        while self.dziala:
            self.obsluga_zdarzen()
            self.aktualizacja()
            if self.stan_menu == 'gra': self.rysuj_scene_3d()
            else: self.rysuj_ui()
            pygame.display.flip()
            self.zegar.tick(FPS)

if __name__ == "__main__":
    gra = GraHorror3D()
    gra.run()
