"""
main.py - No Signal: 3D Horror Game [STABLE MAZE & FLOAT RAYCASTING FIX]
Zaimplementowano:
1. Przywrócono oryginalne, stabilne generowanie labiryntu (czysty algorytm DFS).
2. Zastąpiono DDA precyzyjnym rzutowaniem zmiennoprzecinkowym (Float Raycasting), co całkowicie usuwa ruchome dziury przy zmianie kąta patrzenia.
3. Pełny kod, gotowy do uruchomienia.
Ścieżka skryptu: main.py
"""

import pygame
import sys
import math
import random

# --- KONFIGURACJA GLOBALNA ---
WERSJA = "9.1.0_StablePure"
SZEROKOSC, WYSOKOSC = 1280, 960
FPS = 60
ROZMIAR_BLOKU = 64  

KOLOR_UI = (255, 255, 255)
KOLOR_BTN = (40, 40, 50)

FOV = math.pi / 3  
HALF_FOV = FOV / 2
NUM_RAYS = 240  
MAX_DEPTH = 800
SCREEN_DIST = (SZEROKOSC / 2) / math.tan(HALF_FOV)
PROJ_COEFF = ROZMIAR_BLOKU * SCREEN_DIST
SCALE = SZEROKOSC // NUM_RAYS

# Powrót do mniejszego, stabilnego rozmiaru labiryntu
LAB_SZEROKOSC = 19
LAB_WYSOKOSC = 19

class GraHorror3D:
    def __init__(self):
        pygame.init()
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
        except:
            pass
            
        self.ekran = pygame.display.set_mode((SZEROKOSC, WYSOKOSC))
        pygame.display.set_caption(f"No Signal 3D - Pure Fixed (v{WERSJA})")
        self.zegar = pygame.time.Clock()

        self.dziala = True
        self.stan_menu = 'wpisywanie_nicku'  
        self.aktualny_poziom = 1
        
        self.latarka_wlaczona = True
        self.mysz_zainicjalizowana = False
        self.mysz_zablokowana = True  

        self.moje_x = 96.0
        self.moje_y = 96.0
        self.moje_kat = 0.0  
        self.moje_pitch = 0.0  
        self.predkosc_ruchu = 3.5  
        self.czulosc_myszy = 0.0020

        self.licznik_chodzenia = 0.0
        self.bujanie_glowy_y = 0.0
        self.bateria = 100.0
        self.max_bateria = 100.0

        self.emf_timer = 0
        self.emf_dioda_swieci = False
        self.emf_dystans = 999.0
        self.cached_sounds = {}
        self.pre_generuj_dzwieki_emf()

        self.moj_nick = "Gracz"
        self.przedmioty = [] 
        self.zebrane_klucze = 0
        self.wymagane_klucze = 1
        
        self.drzwi_kafelki = set()
        self.mapa_struktura = []
        
        self.font_main = pygame.font.SysFont("Arial", 32)
        self.font_small = pygame.font.SysFont("Arial", 24)
        self.font_tiny = pygame.font.SysFont("Arial", 18)
        self.font_big = pygame.font.SysFont("Arial", 40)

        self.btn_single = pygame.Rect(100, 200, 500, 60)
        
        self.tekstura_sciany = self.generuj_powierzchnie_realistycznej_sciany().convert()
        self.tekstura_drzwi = self.generuj_powierzchnie_drzwi().convert()

    def pre_generuj_dzwieki_emf(self):
        sample_rate = 22050
        duration = 0.035
        n_samples = int(duration * sample_rate)
        
        for freq in [350, 500, 800]:
            buf = bytearray()
            for i in range(n_samples):
                t = float(i) / sample_rate
                val = int(math.sin(2.0 * math.pi * freq * t) * 12000)
                buf.extend(val.to_bytes(2, byteorder='little', signed=True))
            try:
                snd = pygame.mixer.Sound(buffer=buf)
                snd.set_volume(0.12)
                self.cached_sounds[freq] = snd
            except:
                self.cached_sounds[freq] = None

    def odtworz_emf_sound(self, freq):
        if freq in self.cached_sounds and self.cached_sounds[freq]:
            self.cached_sounds[freq].play()

    def generuj_powierzchnie_realistycznej_sciany(self):
        powierzchnia = pygame.Surface((ROZMIAR_BLOKU, ROZMIAR_BLOKU))
        powierzchnia.fill((50, 46, 48)) 
        for y in range(ROZMIAR_BLOKU):
            przesuniecie_bloku = 24 if (y // 14) % 2 == 0 else 0
            for x in range(ROZMIAR_BLOKU):
                jest_fuga_h = abs((y % 14) - 0) <= 1 or (y == ROZMIAR_BLOKU - 1)
                jest_fuga_v = abs(((x + przesuniecie_bloku) % 28) - 0) <= 1 or (x == ROZMIAR_BLOKU - 1)
                if jest_fuga_h or jest_fuga_v:
                    powierzchnia.set_at((x, y), (15, 15, 18))
                else:
                    szum = random.randint(-4, 4)
                    powierzchnia.set_at((x, y), (max(35, min(90, 60 + szum)), max(35, min(90, 55 + szum)), max(35, min(90, 53 + szum))))
        return powierzchnia

    def generuj_powierzchnie_drzwi(self):
        powierzchnia = pygame.Surface((ROZMIAR_BLOKU, ROZMIAR_BLOKU))
        powierzchnia.fill((85, 48, 28)) 
        for y in range(ROZMIAR_BLOKU):
            for x in range(ROZMIAR_BLOKU):
                szum = random.randint(-4, 4)
                if x % 16 <= 1 or x == ROZMIAR_BLOKU - 1 or y % 32 <= 1:
                    powierzchnia.set_at((x, y), (35, 20, 10)) 
                else:
                    powierzchnia.set_at((x, y), (max(0, 75+szum), max(0, 42+szum), max(0, 22+szum)))
        return powierzchnia

    def konfiguruj_poziom(self):
        if self.aktualny_poziom == 1:
            self.wymagane_klucze = 1
            liczba_baterii = 2
        elif self.aktualny_poziom == 2:
            self.wymagane_klucze = 2
            liczba_baterii = 3
        else:
            self.wymagane_klucze = 3
            liczba_baterii = 4
        self.zebrane_klucze = 0
        self.przedmioty.clear()
        self.generuj_labirynt(liczba_baterii)

    def generuj_labirynt(self, liczba_baterii):
        szer, wys = LAB_SZEROKOSC, LAB_WYSOKOSC
        self.mapa_struktura = [[1 for _ in range(szer)] for _ in range(wys)]
        self.drzwi_kafelki.clear()

        # Klasyczny, stabilny generator DFS (jak na początku)
        odwiedzone = set()
        stos = [(1, 1)]
        self.mapa_struktura[1][1] = 0
        odwiedzone.add((1, 1))

        while stos:
            cx, cy = stos[-1]
            sasiedzi = []
            kierunki = [(0, -2), (2, 0), (0, 2), (-2, 0)]
            for dx, dy in kierunki:
                nx, ny = cx + dx, cy + dy
                if 0 < nx < szer - 1 and 0 < ny < wys - 1 and (nx, ny) not in odwiedzone:
                    sasiedzi.append((nx, ny, dx // 2, dy // 2))
            if sasiedzi:
                nx, ny, d_x, d_y = random.choice(sasiedzi)
                self.mapa_struktura[cy + d_y][cx + d_x] = 0
                self.mapa_struktura[ny][nx] = 0
                odwiedzone.add((nx, ny))
                stos.append((nx, ny))
            else:
                stos.pop()

        wolne_punkty = []
        for y in range(1, wys - 1):
            for x in range(1, szer - 1):
                if self.mapa_struktura[y][x] == 0 and (x > 1 or y > 1):
                    wolne_punkty.append((x, y))
        random.shuffle(wolne_punkty)

        kolory_kluczy = [(255, 215, 0), (240, 40, 40), (40, 220, 40)] 
        for i in range(self.wymagane_klucze):
            if wolne_punkty:
                kx, ky = wolne_punkty.pop()
                self.przedmioty.append({
                    'x': kx * ROZMIAR_BLOKU + 32, 'y': ky * ROZMIAR_BLOKU + 32, 'typ': 'klucz', 'kolor': kolory_kluczy[i], 
                    'nazwa': "ZŁOTY KLUCZ" if i==0 else ("CZERWONY KLUCZ" if i==1 else "ZIELONY KLUCZ")
                })

        for _ in range(liczba_baterii):
            if wolne_punkty:
                bx, by = wolne_punkty.pop()
                self.przedmioty.append({
                    'x': bx * ROZMIAR_BLOKU + 32, 'y': by * ROZMIAR_BLOKU + 32, 'typ': 'bateria', 'kolor': (30, 144, 255), 'nazwa': "BATERIĘ"
                })

        # Wyjście (drzwi) zawsze na końcu jednej ze ścieżek
        if wolne_punkty:
            dx, dy = wolne_punkty.pop()
            self.mapa_struktura[dy][dx] = 2
            self.drzwi_kafelki.add((dx, dy))

        self.moje_x = 1 * ROZMIAR_BLOKU + 32
        self.moje_y = 1 * ROZMIAR_BLOKU + 32

    def ruch_i_kolizje(self, dx, dy):
        PROMIEN = 16
        for nx, ny in [(self.moje_x + dx, self.moje_y), (self.moje_x, self.moje_y + dy)]:
            mx = int((nx + (PROMIEN if dx > 0 else -PROMIEN)) // ROZMIAR_BLOKU)
            my = int((ny + (PROMIEN if dy > 0 else -PROMIEN)) // ROZMIAR_BLOKU)
            if 0 <= mx < LAB_SZEROKOSC and 0 <= my < LAB_WYSOKOSC:
                if self.mapa_struktura[my][mx] in [0, 2]:
                    if nx == self.moje_x + dx: self.moje_x = nx
                    else: self.moje_y = ny

        cx, cy = int(self.moje_x // ROZMIAR_BLOKU), int(self.moje_y // ROZMIAR_BLOKU)
        if (cx, cy) in self.drzwi_kafelki and self.zebrane_klucze == self.wymagane_klucze:
            if self.aktualny_poziom < 3:
                self.aktualny_poziom += 1
                self.konfiguruj_poziom()
            else:
                self.stan_menu = 'glowne_menu'
                self.mysz_zablokowana = False
                pygame.mouse.set_visible(True)

    def rysuj_scene_3d(self):
        self.ekran.fill((5, 5, 5)) 
        
        centr_y = WYSOKOSC // 2 + self.moje_pitch + self.bujanie_glowy_y
        z_buffer = [MAX_DEPTH] * NUM_RAYS
        ox, oy = self.moje_x, self.moje_y
        
        kat_startowy = self.moje_kat - HALF_FOV
        krok_kata = FOV / NUM_RAYS

        # --- TŁO: SUFIT I PODŁOGA ---
        for screen_y in range(0, WYSOKOSC, 4):
            dy_floor = screen_y - centr_y
            if dy_floor == 0: continue
            
            dist_floor = PROJ_COEFF / (2.0 * abs(dy_floor))
            if dist_floor > MAX_DEPTH: continue
            
            if self.latarka_wlaczona:
                wsp_f = max(0.01, (1.0 - (dist_floor / 500.0)) ** 2)
            else:
                wsp_f = max(0.01, (1.0 - (dist_floor / 150.0)) * 0.15)
                
            col_floor = (int(26 * wsp_f), int(24 * wsp_f), int(25 * wsp_f))
            col_ceiling = (int(14 * wsp_f), int(14 * wsp_f), int(16 * wsp_f))
            
            if dy_floor > 0:
                pygame.draw.rect(self.ekran, col_floor, (0, screen_y, SZEROKOSC, 4))
            else:
                pygame.draw.rect(self.ekran, col_ceiling, (0, screen_y, SZEROKOSC, 4))

        # --- ZMIENNOPRZECINKOWE RZUTOWANIE PROMIENI (BRAK SZCZELIN) ---
        STEP_SIZE = 2.0  # Mały, stały krok gwarantuje brak pominięcia geometrii bloków
        
        for ray in range(NUM_RAYS):
            kat_promienia = kat_startowy + ray * krok_kata
            sin_a = math.sin(kat_promienia)
            cos_a = math.cos(kat_promienia)

            depth = 0.0
            hit = 0
            hit_x, hit_y = 0, 0

            while depth < MAX_DEPTH:
                depth += STEP_SIZE
                cx = ox + depth * cos_a
                cy = oy + depth * sin_a

                mx, my = int(cx // ROZMIAR_BLOKU), int(cy // ROZMIAR_BLOKU)
                if 0 <= mx < LAB_SZEROKOSC and 0 <= my < LAB_WYSOKOSC:
                    if self.mapa_struktura[my][mx] in [1, 2]:
                        hit = self.mapa_struktura[my][mx]
                        hit_x, hit_y = cx, cy
                        break
                else:
                    break

            if hit == 0:
                continue

            dist_kor = depth * math.cos(kat_promienia - self.moje_kat)
            dist_kor = max(1.0, dist_kor)
            z_buffer[ray] = dist_kor

            # Światło latarki
            if self.latarka_wlaczona:
                spadek_odl = max(0.0, 1.0 - (dist_kor / 600))
                roznica_srodka = (kat_promienia - self.moje_kat + math.pi) % (2 * math.pi) - math.pi
                latarka_moc = spadek_odl * ((1.0 - (abs(roznica_srodka) / (HALF_FOV * 1.1))) ** 2) if abs(roznica_srodka) < HALF_FOV * 1.1 else 0.0
                wsp_swiatla = max(max(0.02, 1.0 - (dist_kor / 220)) * 0.12, latarka_moc)
            else:
                wsp_swiatla = max(0.02, 1.0 - (dist_kor / 120)) * 0.15

            wsp_swiatla = max(0.02, min(1.0, wsp_swiatla))

            wysokosc_sciany = int(PROJ_COEFF / dist_kor)
            wall_top = centr_y - wysokosc_sciany // 2

            # Obliczenie tekstury na podstawie pozycji trafienia promienia
            if abs((hit_x % ROZMIAR_BLOKU) - 0) < 2.1 or abs((hit_x % ROZMIAR_BLOKU) - ROZMIAR_BLOKU) < 2.1:
                tex_x = int(hit_y % ROZMIAR_BLOKU)
            else:
                tex_x = int(hit_x % ROZMIAR_BLOKU)

            tekstura = self.tekstura_sciany if hit == 1 else self.tekstura_drzwi
            
            pasek = pygame.Surface((1, ROZMIAR_BLOKU))
            pasek.blit(tekstura, (0, 0), (tex_x % ROZMIAR_BLOKU, 0, 1, ROZMIAR_BLOKU))
            
            if wsp_swiatla < 1.0:
                pasek.lock()
                for y_px in range(ROZMIAR_BLOKU):
                    r, g, b, _ = pasek.get_at((0, y_px))
                    pasek.set_at((0, y_px), (int(r * wsp_swiatla), int(g * wsp_swiatla), int(b * wsp_swiatla)))
                pasek.unlock()

            # Rysowanie paska z lekkim nadmiarem szerokości (skalowanie do SCALE + 1) całkowicie usuwa szpary z image_bc2e2e.png
            skalowany_pasek = pygame.transform.scale(pasek, (SCALE + 1, max(1, wysokosc_sciany)))
            self.ekran.blit(skalowany_pasek, (ray * SCALE, wall_top))

        # --- SPRITY PRZEDMIOTÓW ---
        for obj in self.przedmioty:
            dx, dy = obj['x'] - ox, obj['y'] - oy
            dystans = math.hypot(dx, dy)
            gamma = math.atan2(dy, dx) - self.moje_kat
            gamma = (gamma + math.pi) % (2 * math.pi) - math.pi

            if -HALF_FOV < gamma < HALF_FOV and 10 < dystans < (600 if self.latarka_wlaczona else 120):
                dist_kor = dystans * math.cos(gamma)
                screen_x = int((SZEROKOSC / 2) + math.tan(gamma) * SCREEN_DIST)
                wys_obj = int(PROJ_COEFF / max(0.1, dist_kor))
                
                h_o = int(wys_obj * (0.4 if obj['typ']=='klucz' else 0.25))
                w_o = max(3, int(h_o * (0.25 if obj['typ']=='klucz' else 0.5)))
                top_o = (centr_y + int(wys_obj * 0.18)) - h_o // 2
                
                r_idx = screen_x // SCALE
                if 0 <= r_idx < NUM_RAYS and dist_kor < z_buffer[r_idx]:
                    wsp_k = max(0.1, 1.0 - (dist_kor / 450)) if self.latarka_wlaczona else max(0.0, 1.0 - (dist_kor / 110)) * 0.4
                    r, g, b = [int(c * wsp_k) for c in obj['kolor']]
                    pygame.draw.rect(self.ekran, (r, g, b), (screen_x - w_o // 2, top_o, w_o, h_o))

        # --- HUD INTERFEJSU ---
        pygame.draw.circle(self.ekran, (140, 140, 140), (SZEROKOSC // 2, WYSOKOSC // 2), 2)
        pygame.draw.rect(self.ekran, (30, 30, 30), (20, 20, 200, 25))
        pygame.draw.rect(self.ekran, (30, 144, 255) if self.latarka_wlaczona else (80, 80, 80), (20, 20, int(self.bateria * 2), 25))
        
        self.ekran.blit(self.font_small.render(f"POZIOM: {self.aktualny_poziom}/3", True, (255, 255, 255)), (20, 55))
        self.ekran.blit(self.font_small.render(f"KLUCZE: {self.zebrane_klucze}/{self.wymagane_klucze}", True, (235, 210, 40)), (250, 18))

        # PANEL DETEKTORA EMF
        pygame.draw.rect(self.ekran, (20, 20, 25), (20, 90, 240, 65))
        pygame.draw.rect(self.ekran, (70, 70, 85), (20, 90, 240, 65), 1)
        self.ekran.blit(self.font_small.render("EMF:", True, (200, 200, 200)), (30, 96))
        
        if self.emf_dystans > 400: opis, kolor_d = "NISKI", ((160, 20, 20) if self.emf_dioda_swieci else (40, 5, 5))
        elif self.emf_dystans > 150: opis, kolor_d = "ZBLIŻANIE", ((240, 180, 20) if self.emf_dioda_swieci else (60, 45, 5))
        else: opis, kolor_d = "BLISKO!", ((30, 250, 60) if self.emf_dioda_swieci else (5, 60, 10))
            
        self.ekran.blit(self.font_small.render(opis, True, kolor_d if self.emf_dioda_swieci else (120, 120, 120)), (85, 96))
        pygame.draw.circle(self.ekran, kolor_d, (235, 111), 10)

        dystans_w_metrach = (self.emf_dystans / ROZMIAR_BLOKU) * 3.0
        txt_meters = self.font_tiny.render(f"DYSTANS: {dystans_w_metrach:.1f} m", True, (180, 185, 190))
        self.ekran.blit(txt_meters, (30, 128))

        for obj in self.przedmioty:
            if math.hypot(obj['x'] - ox, obj['y'] - oy) < 55.0:
                txt = self.font_main.render(f"Naciśnij [F], aby podnieść {obj['nazwa']}", True, (255, 255, 100))
                self.ekran.blit(txt, (SZEROKOSC // 2 - txt.get_width() // 2, WYSOKOSC - 150))
                break

    def zablokuj_mysz_gry(self):
        self.mysz_zablokowana = True
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
        pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
        self.mysz_zainicjalizowana = False

    def obsluga_zdarzen(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.dziala = False
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if self.stan_menu == 'wpisywanie_nicku':
                    if event.key == pygame.K_RETURN and self.moj_nick.strip(): self.stan_menu = 'glowne_menu'
                    elif event.key == pygame.K_BACKSPACE: self.moj_nick = self.moj_nick[:-1]
                    else:
                        if len(self.moj_nick) < 14 and (event.unicode.isalnum() or event.unicode in [' ', '_', '-']): self.moj_nick += event.unicode
                elif self.stan_menu == 'gra':
                    if event.key == pygame.K_ESCAPE:
                        self.mysz_zablokowana = not self.mysz_zablokowana
                        pygame.mouse.set_visible(not self.mysz_zablokowana)
                        pygame.event.set_grab(self.mysz_zablokowana)
                    if event.key == pygame.K_f:
                        naj_idx = -1
                        min_d = 55.0
                        for idx, obj in enumerate(self.przedmioty):
                            d = math.hypot(obj['x'] - self.moje_x, obj['y'] - self.moje_y)
                            if d < min_d: min_d = d; naj_idx = idx
                        if naj_idx != -1:
                            o = self.przedmioty.pop(naj_idx)
                            if o['typ'] == 'klucz': self.zebrane_klucze += 1
                            else: self.bateria = min(self.max_bateria, self.bateria + 35.0)
                        else:
                            if self.bateria > 0: self.latarka_wlaczona = not self.latarka_wlaczona

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.stan_menu == 'glowne_menu' and self.btn_single.collidepoint(pygame.mouse.get_pos()):
                    self.aktualny_poziom = 1; self.konfiguruj_poziom(); self.stan_menu = 'gra'; self.zablokuj_mysz_gry()
                elif self.stan_menu == 'gra' and not self.mysz_zablokowana: self.zablokuj_mysz_gry()

    def aktualizacja(self):
        if self.stan_menu != 'gra': return

        if self.mysz_zablokowana:
            mx, my = pygame.mouse.get_pos()
            if not self.mysz_zainicjalizowana:
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
                self.mysz_zainicjalizowana = True
            else:
                self.moje_kat += (mx - SZEROKOSC // 2) * self.czulosc_myszy
                self.moje_pitch = max(-200, min(200, self.moje_pitch - (my - WYSOKOSC // 2) * 1.2))
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)

        klawisze = pygame.key.get_pressed()
        dx, dy = 0.0, 0.0
        cos_a, sin_a = math.cos(self.moje_kat), math.sin(self.moje_kat)

        idzie = False
        if klawisze[pygame.K_w]: dx += cos_a; dy += sin_a; idzie = True
        if klawisze[pygame.K_s]: dx -= cos_a; dy -= sin_a; idzie = True
        if klawisze[pygame.K_a]: dx += sin_a; dy -= cos_a; idzie = True
        if klawisze[pygame.K_d]: dx -= sin_a; dy += cos_a; idzie = True

        if idzie:
            dl = math.hypot(dx, dy)
            self.ruch_i_kolizje((dx / dl) * self.predkosc_ruchu, (dy / dl) * self.predkosc_ruchu)
            self.licznik_chodzenia += 0.22
            self.bujanie_glowy_y = math.sin(self.licznik_chodzenia) * 4.5
        else:
            self.bujanie_glowy_y *= 0.75

        self.bateria = max(0, self.bateria - (0.022 if self.latarka_wlaczona else -0.015))
        if self.bateria == 0: self.latarka_wlaczona = False
        if self.bateria >= self.max_bateria: self.bateria = self.max_bateria

        min_d = 9999.0
        if self.zebrane_klucze < self.wymagane_klucze:
            for obj in self.przedmioty:
                if obj['typ'] == 'klucz':
                    d = math.hypot(obj['x'] - self.moje_x, obj['y'] - self.moje_y)
                    if d < min_d: min_d = d
        else:
            for kx, ky in self.drzwi_kafelki:
                d = math.hypot((kx*64+32) - self.moje_x, (ky*64+32) - self.moje_y)
                if d < min_d: min_d = d

        self.emf_dystans = min_d
        interwal = 45 if self.emf_dystans > 400 else (20 if self.emf_dystans > 150 else 6)

        self.emf_timer += 1
        if self.emf_timer >= interwal:
            self.emf_timer = 0
            self.emf_dioda_swieci = not self.emf_dioda_swieci
            if self.emf_dioda_swieci:
                freq = 800 if self.emf_dystans < 150 else (500 if self.emf_dystans < 400 else 350)
                self.odtworz_emf_sound(freq)

    def rysuj_ui(self):
        self.ekran.fill((15, 15, 20))
        if self.stan_menu == 'wpisywanie_nicku':
            self.ekran.blit(self.font_big.render("NO SIGNAL: 3D HORROR", True, (210, 20, 20)), (SZEROKOSC // 2 - 200, 220))
            self.ekran.blit(self.font_main.render("Wpisz swój nick i naciśnij ENTER:", True, KOLOR_UI), (SZEROKOSC // 2 - 200, 420))
            self.ekran.blit(self.font_big.render(self.moj_nick + "_", True, (240, 240, 250)), (SZEROKOSC // 2 - 100, 500))
        elif self.stan_menu == 'glowne_menu':
            self.ekran.blit(self.font_big.render(f"Witaj, {self.moj_nick}! Wybierz tryb:", True, KOLOR_UI), (100, 100))
            pygame.draw.rect(self.ekran, KOLOR_BTN, self.btn_single)
            self.ekran.blit(self.font_main.render("URUCHOM PROGRESYWNĄ KAMPANIĘ", True, KOLOR_UI), (self.btn_single.x + 15, self.btn_single.y + 12))
            self.ekran.blit(self.font_small.render("Zwrócono stabilny generator DFS oraz usunięto szczeliny rzutowania!", True, (20, 240, 50)), (100, 350))

    def run(self):
        while self.dziala:
            self.obsluga_zdarzen()
            self.aktualizacja()
            if self.stan_menu == 'gra': self.rysuj_scene_3d()
            else: self.rysuj_ui()
            pygame.display.flip()
            self.zegar.tick(FPS)

if __name__ == "__main__":
    GraHorror3D().run()
