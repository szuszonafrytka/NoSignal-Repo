"""
main.py - No Signal: 3D Horror Game [POZIOM 01 - SYSTEM PIĘTER I SCHODÓW]
Zaimplementowano: Poziom 01 jako trójwymiarowy budynek (piwnica, parter, poddasze).
Mechanika: Całkowita korekta spawnu (112, 176) zapobiegająca utknięciu w ścianie.
"""

import pygame
import socket
import threading
import time
import sys
import random
import math

# --- KONFIGURACJA GLOBALNA I WERYFIKACJA WERSJI ---
WERSJA = "3.7"
SZEROKOSC, WYSOKOSC = 1280, 960
FPS = 60
ROZMIAR_BLOKU = 32

KOLOR_UI = (255, 255, 255)
KOLOR_BTN = (40, 40, 50)

FOV = math.pi / 3  
HALF_FOV = FOV / 2
NUM_RAYS = 320  
MAX_DEPTH = 650  
SCREEN_DIST = (SZEROKOSC / 2) / math.tan(HALF_FOV)
PROJ_COEFF = ROZMIAR_BLOKU * SCREEN_DIST
SCALE = SZEROKOSC // NUM_RAYS

PORT_BROADCAST = 5556

# --- STRUKTURA POZIOMÓW (POZIOM 01 ZAWIERA 3 PIĘTRA) ---
GRY_POZIOMY = {
    "Poziom 01": {
        "piwnica": [
            ["1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"],
            ["1", "0", "0", "0", "0", "0", "1", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "1"],
            ["1", "0", "D", "0", "0", "0", "1", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "1"],
            ["1", "0", "0", "0", "0", "0", "1", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "1"],
            ["1", "0", "0", "0", "0", "0", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "0", "1"],
            ["1", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "W", "1"],
            ["1", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "1"],
            ["1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"]
        ],
        "parter": [
            ["1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"],
            ["1", "G", "G", "G", "G", "1", "P", "P", "P", "1", "V", "V", "V", "V", "V", "V", "V", "V", "V", "1"],
            ["1", "G", "G", "G", "G", "1", "P", "P", "P", "1", "V", "V", "V", "V", "V", "V", "V", "V", "V", "W"],
            ["1", "G", "D", "G", "G", "1", "1", "0", "1", "1", "V", "V", "V", "V", "V", "V", "V", "V", "V", "1"],
            ["1", "G", "G", "G", "G", "0", "0", "0", "0", "0", "V", "V", "V", "V", "V", "V", "V", "V", "V", "1"],
            ["1", "0", "0", "0", "0", "0", "1", "1", "1", "1", "V", "V", "V", "V", "V", "V", "V", "V", "V", "S"],
            ["S", "0", "0", "0", "0", "0", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"],
            ["1", "0", "0", "0", "1", "1", "C", "C", "C", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"],
            ["1", "0", "0", "0", "1", "1", "C", "C", "C", "1", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "1"],
            ["1", "0", "0", "0", "1", "1", "C", "C", "C", "1", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "W"],
            ["1", "R", "R", "R", "1", "1", "C", "C", "C", "1", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "1"],
            ["1", "1", "1", "1", "1", "1", "W", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"]
        ],
        "poddasze": [
            ["1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"],
            ["1", "G", "G", "G", "G", "1", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "1"],
            ["1", "G", "G", "G", "G", "1", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "1"],
            ["1", "B", "B", "B", "B", "1", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "1"],
            ["1", "B", "B", "B", "B", "M", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "1"],
            ["1", "B", "B", "B", "B", "1", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "1"],
            ["1", "B", "B", "B", "B", "1", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "1"],
            ["1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "S", "1"],
            ["1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"]
        ]
    }
}

class GraHorror3D:
    def __init__(self):
        pygame.init()
        self.ekran = pygame.display.set_mode((SZEROKOSC, WYSOKOSC))
        pygame.display.set_caption(f"No Signal 3D - Multiplayer Horror (v{WERSJA})")
        self.zegar = pygame.time.Clock()

        self.dziala = True
        self.stan_menu = 'wpisywanie_nicku'  
        self.rola = None 
        
        self.wybrany_lvl_nazwa = "Poziom 01"
        self.aktualne_pietro = "parter"  
        self.komunikat_bledu = ""

        self.fullscreen = False
        self.latarka_wlaczona = True
        self.mysz_zainicjalizowana = False
        self.mysz_zablokowana = True  

        # Nowe, w pełni bezpieczne współrzędne (x=3, y=5 na mapie to "0")
        self.moje_x = 112.0
        self.moje_y = 176.0
        self.moje_kat = 0.0  # Patrzy w prawo, w stronę długiego korytarza
        self.moje_pitch = 0.0  
        self.predkosc_ruchu = 1.6  
        self.czulosc_myszy = 0.0025
        self.idzie_teraz = False  

        self.licznik_chodzenia = 0.0
        self.bujanie_glowy_y = 0.0
        self.bateria = 100.0
        self.max_bateria = 100.0

        self.moj_nick = "Gracz"
        self.nazwa_serwera = "Serwer_1"  
        
        self.mapa_struktura = []
        self.mapa_w = 0
        self.mapa_h = 0
        
        self.font_main = pygame.font.SysFont("Arial", 32)
        self.font_small = pygame.font.SysFont("Arial", 24)
        self.font_big = pygame.font.SysFont("Arial", 40)

        self.wybrany_serwer_ip = None
        self.wybrany_serwer_port = 5555
        self.wykryte_serwery = {}
        self.klienci = {}
        self.inni_gracze = {}

        self.btn_single = pygame.Rect(100, 200, 500, 60)
        self.btn_multi = pygame.Rect(100, 280, 500, 60)
        
        self.btn_lvl01 = pygame.Rect(100, 200, 300, 60)
        self.btn_start_host = pygame.Rect(100, 320, 400, 60)

        self.serwery_przyciski = []
        threading.Thread(target=self.sluchaj_obecnosci, daemon=True).start()

    def zaladuj_mape(self):
        szablon = GRY_POZIOMY[self.wybrany_lvl_nazwa][self.aktualne_pietro]
        self.mapa_h = len(szablon)
        self.mapa_w = len(szablon[0])

        self.mapa_struktura = []
        for row in szablon:
            nowy_wiersz = []
            for komorka in row:
                if komorka in ["0", "W", "S"]:  
                    nowy_wiersz.append(0)
                else:
                    nowy_wiersz.append(1)  
            self.mapa_struktura.append(nowy_wiersz)

    def sprawdz_schody(self):
        szablon = GRY_POZIOMY[self.wybrany_lvl_nazwa][self.aktualne_pietro]
        b_x = int(self.moje_x // ROZMIAR_BLOKU)
        b_y = int(self.moje_y // ROZMIAR_BLOKU)

        if 0 <= b_x < self.mapa_w and 0 <= b_y < self.mapa_h:
            kafelek = szablon[b_y][b_x]
            stare_pietro = self.aktualne_pietro

            if kafelek == "W":  
                if self.aktualne_pietro == "piwnica":
                    self.aktualne_pietro = "parter"
                elif self.aktualne_pietro == "parter":
                    self.aktualne_pietro = "poddasze"
            elif kafelek == "S":  
                if self.aktualne_pietro == "poddasze":
                    self.aktualne_pietro = "parter"
                elif self.aktualne_pietro == "parter":
                    self.aktualne_pietro = "piwnica"

            if self.aktualne_pietro != stare_pietro:
                self.zaladuj_mape()
                self.moje_x += math.cos(self.moje_kat) * 15
                self.moje_y += math.sin(self.moje_kat) * 15

    def nadawaj_obecnosc(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while self.dziala and self.rola == 'serwer':
            try:
                msg = f"3D_HORROR_SRV:{WERSJA}:{self.nazwa_serwera}:5555:{self.wybrany_lvl_nazwa}:{self.aktualne_pietro}".encode('utf-8')
                s.sendto(msg, ('<broadcast>', PORT_BROADCAST))
            except: pass
            time.sleep(1)

    def sluchaj_obecnosci(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('', PORT_BROADCAST))
        s.settimeout(0.5)
        while self.dziala:
            if self.stan_menu in ['glowne_menu', 'wybor_lvl']:
                try:
                    dane, adres = s.recvfrom(1024)
                    tekst = dane.decode('utf-8', errors='ignore')
                    if tekst.startswith("3D_HORROR_SRV:"):
                        parts = tekst.split(":")
                        if len(parts) >= 6:
                            wersja_serwera = parts[1].strip()
                            if wersja_serwera == WERSJA:
                                self.wykryte_serwery[parts[2].strip()] = (adres[0], int(parts[3]), parts[4].strip(), parts[5].strip(), time.time())
                except: pass
                teraz = time.time()
                nieaktywne = [n for n, (ip, p, lvl, p_tr, t) in self.wykryte_serwery.items() if teraz - t > 4.0]
                for n in nieaktywne: del self.wykryte_serwery[n]
            else:
                time.sleep(0.5)

    def odpal_serwer_sieciowy(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try: s.bind(('', 5555))
        except: pass
        s.settimeout(0.5)
        while self.dziala and self.rola == 'serwer':
            try:
                dane, adres = s.recvfrom(1024)
                paczka = dane.decode().split(",")
                if paczka[0] != WERSJA: continue

                key = f"{adres[0]}:{adres[1]}"
                pietro_klienta = paczka[7] if len(paczka) >= 8 else "parter"

                self.klienci[key] = {
                    'x': float(paczka[1]), 'y': float(paczka[2]), 
                    'kat': float(paczka[3]), 'nick': paczka[4], 
                    'latarka': int(paczka[5]), 'idzie': int(paczka[6]), 
                    'pietro': pietro_klienta, 'czas': time.time()
                }

                res = f"{WERSJA};{self.moje_x};{self.moje_y};{self.moje_kat};{self.moj_nick};{int(self.latarka_wlaczona)};{int(self.idzie_teraz)};{self.aktualne_pietro}|"
                for k_id, data in self.klienci.items():
                    if k_id != key:
                        res += f"{data['x']};{data['y']};{data['kat']};{data['nick']};{data['latarka']};{data['idzie']};{data['pietro']}|"
                s.sendto(res.encode(), adres)
            except: pass
            teraz = time.time()
            rozlaczeni = [k for k, v in self.klienci.items() if teraz - v['czas'] > 3.0]
            for k in rozlaczeni: del self.klienci[k]

    def odpal_klienta_sieciowy(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(1.5)
        while self.dziala and self.rola == 'klient':
            try:
                payload = f"{WERSJA},{self.moje_x},{self.moje_y},{self.moje_kat},{self.moj_nick},{int(self.latarka_wlaczona)},{int(self.idzie_teraz)},{self.aktualne_pietro}"
                s.sendto(payload.encode(), (self.wybrany_serwer_ip, self.wybrany_serwer_port))
                dane, _ = s.recvfrom(2048)
                
                dekodowane = dane.decode().split("|")
                if dekodowane and dekodowane[0]:
                    el_s = dekodowane[0].split(";")
                    if el_s[0] != WERSJA:
                        self.komunikat_bledu = "Blad: Niekompatybilna wersja serwera!"
                        self.stan_menu = 'glowne_menu'
                        self.rola = None
                        break

                nowi_gracze = {}
                for i, czesc in enumerate(dekodowane):
                    if czesc:
                        elementy = czesc.split(";")
                        if i == 0 and len(elementy) >= 8:
                            nowi_gracze[i] = {
                                'x': float(elementy[1]), 'y': float(elementy[2]), 'kat': float(elementy[3]), 
                                'nick': elementy[4], 'latarka': int(elementy[5]), 'idzie': int(elementy[6]), 'pietro': elementy[7]
                            }
                        elif i > 0 and len(elementy) >= 7:
                            nowi_gracze[i] = {
                                'x': float(elementy[0]), 'y': float(elementy[1]), 'kat': float(elementy[2]), 
                                'nick': elementy[3], 'latarka': int(elementy[4]), 'idzie': int(elementy[5]), 'pietro': elementy[6]
                            }
                self.inni_gracze = nowi_gracze
            except:
                self.inni_gracze = {}
            time.sleep(0.02)

    def ruch_i_kolizje(self, dx, dy):
        PROMIEN_GRACZA = 10  
        nowe_x = self.moje_x + dx
        margines_x = PROMIEN_GRACZA if dx > 0 else -PROMIEN_GRACZA
        
        try:
            map_x = int((nowe_x + margines_x) // ROZMIAR_BLOKU)
            map_y = int(self.moje_y // ROZMIAR_BLOKU)
            if 0 <= map_x < self.mapa_w and 0 <= map_y < self.mapa_h:
                if self.mapa_struktura[map_y][map_x] == 0:
                    self.moje_x = nowe_x
        except IndexError: pass
            
        nowe_y = self.moje_y + dy
        margines_y = PROMIEN_GRACZA if dy > 0 else -PROMIEN_GRACZA
        try:
            map_x = int(self.moje_x // ROZMIAR_BLOKU)
            map_y = int((nowe_y + margines_y) // ROZMIAR_BLOKU)
            if 0 <= map_x < self.mapa_w and 0 <= map_y < self.mapa_h:
                if self.mapa_struktura[map_y][map_x] == 0:
                    self.moje_y = nowe_y
        except IndexError: pass

    def rysuj_scene_3d(self):
        centr_y = WYSOKOSC // 2 + self.moje_pitch + self.bujanie_glowy_y
        self.ekran.fill((0, 0, 0))

        pelna_lista = self.klienci.values() if self.rola == 'serwer' else self.inni_gracze.values()
        dane_graczy = [d for d in pelna_lista if d.get('pietro', 'parter') == self.aktualne_pietro]

        z_buffer = [MAX_DEPTH] * NUM_RAYS
        kat_startowy = self.moje_kat - HALF_FOV

        for ray in range(NUM_RAYS):
            kat_promienia = kat_startowy + ray * (FOV / NUM_RAYS)
            sin_a = math.sin(kat_promienia)
            cos_a = math.cos(kat_promienia)

            for glebokosc in range(1, MAX_DEPTH, 1):
                cel_x = self.moje_x + glebokosc * cos_a
                cel_y = self.moje_y + glebokosc * sin_a

                b_x = int(cel_x // ROZMIAR_BLOKU)
                b_y = int(cel_y // ROZMIAR_BLOKU)

                if 0 <= b_x < self.mapa_w and 0 <= b_y < self.mapa_h:
                    if self.mapa_struktura[b_y][b_x] == 1:
                        glebokosc_kor = glebokosc * math.cos(kat_promienia - self.moje_kat)
                        glebokosc_kor = max(glebokosc_kor, 0.0001)
                        
                        z_buffer[ray] = glebokosc_kor
                        wysokosc_sciany = int(PROJ_COEFF / glebokosc_kor)
                        wall_top = centr_y - wysokosc_sciany // 2

                        roznica_srodka = kat_promienia - self.moje_kat
                        roznica_srodka = (roznica_srodka + math.pi) % (2 * math.pi) - math.pi

                        if self.latarka_wlaczona:
                            MAX_WIDOCZNOSC = 450
                            ST_LATARKI = math.pi / 4
                            if abs(roznica_srodka) < ST_LATARKI:
                                wsp_swiatla = max(0.0, 1.0 - (glebokosc / MAX_WIDOCZNOSC))
                                wsp_swiatla *= (1.0 - (abs(roznica_srodka) / ST_LATARKI))
                            else: wsp_swiatla = 0.0
                        else:
                            wsp_swiatla = max(0.0, 1.0 - (glebokosc / 65)) * 0.2

                        for d in dane_graczy:
                            if d.get('latarka', 0) == 1:
                                dx_k = cel_x - d['x']
                                dy_k = cel_y - d['y']
                                dystans_kumpla = math.hypot(dx_k, dy_k)
                                if dystans_kumpla < 450:
                                    kat_do_sciany = math.atan2(dy_k, dx_k)
                                    roznica_kata = (kat_do_sciany - d['kat'] + math.pi) % (2 * math.pi) - math.pi
                                    if abs(roznica_kata) < math.pi / 5:
                                        wsp_kumpla = max(0.0, 1.0 - (dystans_kumpla / 450)) * (1.0 - (abs(roznica_kata) / (math.pi / 5)))
                                        if wsp_kumpla > wsp_swiatla: wsp_swiatla = wsp_kumpla

                        if wsp_swiatla > 0.0:
                            r = int(140 * wsp_swiatla)
                            g = int(15 * wsp_swiatla)
                            b = int(15 * wsp_swiatla)
                            pygame.draw.rect(self.ekran, (r, g, b), (ray * SCALE, wall_top, SCALE, wysokosc_sciany))
                        break

        for d in dane_graczy:
            dx = d['x'] - self.moje_x
            dy = d['y'] - self.moje_y
            dystans = math.hypot(dx, dy)

            theta = math.atan2(dy, dx)
            gamma = theta - self.moje_kat
            gamma = (gamma + math.pi) % (2 * math.pi) - math.pi  

            wsp_moje_na_kumplu = 0.0
            if self.latarka_wlaczona:
                if abs(gamma) < math.pi / 4 and dystans < 450:
                    wsp_moje_na_kumplu = max(0.0, 1.0 - (dystans / 450)) * (1.0 - (abs(gamma) / (math.pi / 4)))
            else:
                if dystans < 65: wsp_moje_na_kumplu = max(0.0, 1.0 - (dystans / 65)) * 0.2

            wsp_sw_kumpla = max(wsp_moje_na_kumplu, 0.40 if d.get('latarka', 0) == 1 else 0.0)

            if -HALF_FOV < gamma < HALF_FOV and wsp_sw_kumpla > 0.0:
                dystans_kor = max(dystans * math.cos(gamma), 0.0001)
                screen_x = int((SZEROKOSC / 2) + math.tan(gamma) * SCREEN_DIST)
                wysokosc_sciany = int(PROJ_COEFF / dystans_kor)
                wysokosc_postaci = int(wysokosc_sciany * 0.55)
                szerokosc_postaci = int(wysokosc_postaci * 0.46)
                
                player_bottom = centr_y + wysokosc_sciany // 2  
                player_top = player_bottom - wysokosc_postaci
                
                start_ray = max(0, (screen_x - szerokosc_postaci // 2) // SCALE)
                end_ray = min(NUM_RAYS - 1, (screen_x + szerokosc_postaci // 2) // SCALE)

                for r in range(start_ray, end_ray + 1):
                    if dystans_kor < z_buffer[r]:
                        pygame.draw.rect(self.ekran, (int(55*wsp_sw_kumpla), int(65*wsp_sw_kumpla), int(60*wsp_sw_kumpla)), (r * SCALE, player_top, SCALE, wysokosc_postaci))

                ray_srodek = screen_x // SCALE
                if 0 <= ray_srodek < NUM_RAYS and dystans_kor < z_buffer[ray_srodek] + 20:
                    txt_tag = self.font_small.render(d['nick'], True, (int(220*wsp_sw_kumpla), int(220*wsp_sw_kumpla), int(220*wsp_sw_kumpla)))
                    self.ekran.blit(txt_tag, (screen_x - txt_tag.get_width() // 2, player_top - 30))

        pygame.draw.rect(self.ekran, (30, 30, 30), (20, 20, 200, 25))
        kolor_baterii = (50, 200, 70) if self.bateria > 20 else (220, 40, 40)
        pygame.draw.rect(self.ekran, kolor_baterii, (20, 20, int(self.bateria * 2), 25))
        
        txt_loc = self.font_small.render(f"PIĘTRO: {self.aktualne_pietro.upper()} | LOKALIZACJA: {self.wybrany_lvl_nazwa}", True, KOLOR_UI)
        self.ekran.blit(txt_loc, (250, 18))

    def zablokuj_mysz_gry(self):
        self.mysz_zablokowana = True
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
        pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
        self.mysz_zainicjalizowana = False

    def obsluga_zdarzen(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.dziala = False
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if self.stan_menu == 'wpisywanie_nicku':
                    if event.key == pygame.K_RETURN and self.moj_nick.strip():
                        self.stan_menu = 'glowne_menu'
                    elif event.key == pygame.K_BACKSPACE: self.moj_nick = self.moj_nick[:-1]
                    else:
                        if len(self.moj_nick) < 14 and (event.unicode.isalnum() or event.unicode in [' ', '_', '-']):
                            self.moj_nick += event.unicode

                elif self.stan_menu == 'wpisywanie_serwera':
                    if event.key == pygame.K_RETURN and self.nazwa_serwera.strip():
                        self.rola = 'serwer'
                        self.stan_menu = 'gra'
                        self.aktualne_pietro = "parter"  
                        self.moje_x, self.moje_y = 112.0, 176.0  
                        self.moje_kat = 0.0
                        self.zaladuj_mape()
                        self.zablokuj_mysz_gry()
                        threading.Thread(target=self.nadawaj_obecnosc, daemon=True).start()
                        threading.Thread(target=self.odpal_serwer_sieciowy, daemon=True).start()
                    elif event.key == pygame.K_BACKSPACE: self.nazwa_serwera = self.nazwa_serwera[:-1]
                    else:
                        if len(self.nazwa_serwera) < 16 and (event.unicode.isalnum() or event.unicode in ['_', '-']):
                            self.nazwa_serwera += event.unicode

                elif self.stan_menu == 'gra':
                    if event.key == pygame.K_ESCAPE:
                        self.mysz_zablokowana = not self.mysz_zablokowana
                        pygame.mouse.set_visible(not self.mysz_zablokowana)
                        pygame.event.set_grab(self.mysz_zablokowana)
                    if event.key == pygame.K_f and self.bateria > 0:
                        self.latarka_wlaczona = not self.latarka_wlaczona

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = pygame.mouse.get_pos()
                
                if self.stan_menu == 'glowne_menu':
                    if self.btn_single.collidepoint(pos):
                        self.rola = 'solo'
                        self.stan_menu = 'wybor_lvl'
                    elif self.btn_multi.collidepoint(pos):
                        self.rola = 'serwer_pre'  
                        self.stan_menu = 'wybor_lvl'
                    else:
                        for rect, ip, port, lvl, p_tr in self.serwery_przyciski:
                            if rect.collidepoint(pos):
                                self.wybrany_serwer_ip = ip
                                self.wybrany_serwer_port = port
                                self.wybrany_lvl_nazwa = lvl
                                self.aktualne_pietro = p_tr
                                self.moje_x, self.moje_y = 112.0, 176.0
                                self.moje_kat = 0.0
                                self.rola = 'klient'
                                self.stan_menu = 'gra'
                                self.zaladuj_mape()
                                self.zablokuj_mysz_gry()
                                threading.Thread(target=self.odpal_klienta_sieciowy, daemon=True).start()
                                break

                elif self.stan_menu == 'wybor_lvl':
                    if self.btn_lvl01.collidepoint(pos):
                        self.wybrany_lvl_nazwa = "Poziom 01"
                        if self.rola == 'solo':
                            self.stan_menu = 'gra'
                            self.aktualne_pietro = "parter"  
                            self.moje_x, self.moje_y = 112.0, 176.0
                            self.moje_kat = 0.0
                            self.zaladuj_mape()
                            self.zablokuj_mysz_gry()
                        elif self.rola == 'serwer_pre':
                            self.stan_menu = 'wpisywanie_serwera'

                elif self.stan_menu == 'gra' and not self.mysz_zablokowana:
                    self.zablokuj_mysz_gry()

    def aktualizacja(self):
        if self.stan_menu != 'gra': return

        if self.mysz_zablokowana:
            mx, my = pygame.mouse.get_pos()
            if not self.mysz_zainicjalizowana:
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)
                self.mysz_zainicjalizowana = True
            else:
                self.moje_kat += (mx - SZEROKOSC // 2) * self.czulosc_myszy
                self.moje_pitch = max(-260, min(260, self.moje_pitch - (my - WYSOKOSC // 2) * 1.2))
                pygame.mouse.set_pos(SZEROKOSC // 2, WYSOKOSC // 2)

        klawisze = pygame.key.get_pressed()
        dx, dy = 0.0, 0.0
        cos_a, sin_a = math.cos(self.moje_kat), math.sin(self.moje_kat)

        idzie = False
        if klawisze[pygame.K_w]: dx += cos_a; dy += sin_a; idzie = True
        if klawisze[pygame.K_s]: dx -= cos_a; dy -= sin_a; idzie = True
        if klawisze[pygame.K_a]: dx += sin_a; dy -= cos_a; idzie = True
        if klawisze[pygame.K_d]: dx -= sin_a; dy += cos_a; idzie = True

        self.idzie_teraz = idzie

        if idzie:
            dl = math.hypot(dx, dy)
            self.ruch_i_kolizje((dx / dl) * self.predkosc_ruchu, (dy / dl) * self.predkosc_ruchu)
            self.licznik_chodzenia += 0.22
            self.bujanie_glowy_y = math.sin(self.licznik_chodzenia) * 5.0
            self.sprawdz_schody()  
        else:
            self.bujanie_glowy_y *= 0.75

        if self.latarka_wlaczona:
            self.bateria = max(0, self.bateria - 0.04)
            if self.bateria == 0: self.latarka_wlaczona = False
        else: self.bateria = min(self.max_bateria, self.bateria + 0.015)

    def rysuj_ui(self):
        self.ekran.fill((15, 15, 20))
        
        if self.stan_menu == 'wpisywanie_nicku':
            txt_t = self.font_big.render("NO SIGNAL: 3D HORROR", True, (210, 20, 20))
            self.ekran.blit(txt_t, (SZEROKOSC // 2 - txt_t.get_width() // 2, 220))
            txt_p = self.font_main.render("Wpisz swój nick i naciśnij ENTER:", True, KOLOR_UI)
            self.ekran.blit(txt_p, (SZEROKOSC // 2 - txt_p.get_width() // 2, 420))
            txt_n = self.font_big.render(self.moj_nick + "_", True, (240, 240, 250))
            self.ekran.blit(txt_n, (SZEROKOSC // 2 - txt_n.get_width() // 2, 500))

        elif self.stan_menu == 'glowne_menu':
            txt_t = self.font_big.render("MENU GŁÓWNE GRA", True, KOLOR_UI)
            self.ekran.blit(txt_t, (100, 60))

            pygame.draw.rect(self.ekran, KOLOR_BTN, self.btn_single)
            self.ekran.blit(self.font_main.render("SINGLEPLAYER", True, KOLOR_UI), (self.btn_single.x + 30, self.btn_single.y + 12))

            pygame.draw.rect(self.ekran, KOLOR_BTN, self.btn_multi)
            self.ekran.blit(self.font_main.render("MULTIPLAYER (HOST SERWER)", True, KOLOR_UI), (self.btn_multi.x + 30, self.btn_multi.y + 12))

            self.ekran.blit(self.font_main.render("Dostępne serwery LAN (Kliknij, aby dołączyć):", True, KOLOR_UI), (100, 420))
            self.serwery_przyciski = []
            y_offset = 480
            for name, (ip, port, lvl, p_tr, t) in self.wykryte_serwery.items():
                rect_btn = pygame.Rect(100, y_offset, 650, 50)
                pygame.draw.rect(self.ekran, (30, 50, 40), rect_btn)
                txt_i = self.font_small.render(f"{name} ({ip}) - {lvl} [Piętro: {p_tr.capitalize()}]", True, (200, 255, 200))
                self.ekran.blit(txt_i, (rect_btn.x + 15, rect_btn.y + 12))
                self.serwery_przyciski.append((rect_btn, ip, port, lvl, p_tr))
                y_offset += 60
            if not self.wykryte_serwery:
                self.ekran.blit(self.font_small.render("Skanowanie sieci LAN...", True, (120, 120, 130)), (100, 480))

        elif self.stan_menu == 'wybor_lvl':
            self.ekran.fill((10, 15, 15))
            self.ekran.blit(self.font_big.render("WYBIERZ POZIOM (LEVEL)", True, KOLOR_UI), (100, 80))
            
            pygame.draw.rect(self.ekran, (80, 30, 30), self.btn_lvl01)
            self.ekran.blit(self.font_main.render("Poziom 01 (Dom)", True, KOLOR_UI), (self.btn_lvl01.x + 30, self.btn_lvl01.y + 12))

        elif self.stan_menu == 'wpisywanie_serwera':
            self.ekran.blit(self.font_big.render("KONFIGURACJA SERWERA MULTIPLAYER", True, KOLOR_UI), (100, 80))
            self.ekran.blit(self.font_main.render("Wpisz nazwę pokoju serwera LAN i zatwierdź [ENTER]:", True, KOLOR_UI), (100, 200))
            
            txt_srv_n = self.font_big.render(self.nazwa_serwera + "_", True, (50, 200, 255))
            self.ekran.blit(txt_srv_n, (100, 280))

    def run(self):
        while self.dziala:
            self.obsluga_zdarzen()
            self.aktualizacja()
            if self.stan_menu == 'gra': self.rysuj_scene_3d()
            else: self.rysuj_ui()
            pygame.display.flip()
            self.zegar.tick(FPS)

if __name__ == "__main__":
    gra = GraHorror3D()
    gra.run()
