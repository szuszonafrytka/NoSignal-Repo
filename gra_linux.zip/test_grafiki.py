import pygame
import base64
import io
import sys
import traceback

B64_DANE = "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAACNUlEQVR4AeyVvUtcQRTFrylCIMQYQkggQRKQCGnSJIVFAilTpAgIIUUay/wDgZQWWtnaCIIKiiBoYSc2YidYiaAsiCKiqPgBNjbr/IadYfbtzrw7D8TGZc7ez7nnvLvL7gO549e9gJwN1M2nBYzxhziEL2gdrYD6QG+nADPYExKHaNSM0R+tAD+xQOjzONSMRaAxuqMRYJ/ejRvfuhQHcvhY0PA78LXQCPCEEOyP9ouDi7HAkGaRm35RCXCEWC45uPhbX58c7e2Qzlo/F1QCaExh6s9redn9jpbb2QCTYzidvxAQq5flNRvoePN3Ljrn+c+n8nFpiXr203NJI4A+iYlo5CuRM1gtgOYEsr98blaZAAYDGZnYltnHQ+6etcTkbSBCH2iEOpMSUB+fWRGHZw8PBUDqQAxcD9bQZolICTCzWg+Enz90WjGt1fyMSsDA769Nk2u17aa4WG8qlgRJAWfXrwQUZ/T0vC+mbF+73pbGQiIp4NfVfwGFO1LcAHX6AH4OkgLCQeHTtdtA2JvjqwWMTh/4Na9tXlo/hyjWqxbAgH+DizI8+ciDrQBqVZESEP0POFnutnwIYjM2MG9VfpZTAsxI8SJ2a+vS9bafXFtUIWdQmQB67B9NO3JyCKPJwPYZm3U0AuzA8+Mta8M3cogIc7m+WkBsMCJiNU1eLaDrRa+EZKGvIYr1qAVAGIrAZ6iz+FWgFrCx8ElWx54IFiLnY4mrQi3gx/cv4gCZ87HEMZTlbwAAAP//teMMvgAAAAZJREFUAwDPldII3kHAigAAAABJRU5ErkJggg=="

def testuj_grafike():
    try:
        pygame.init()
        ekran = pygame.display.set_mode((400, 400))
        pygame.display.set_caption("Test Grafiki Gracza")
        
        dane_obrazka = base64.b64decode(B64_DANE)
        strumien = io.BytesIO(dane_obrazka)
        
        # Dodałem "name.png", żeby Pygame wiedziało, z jakim formatem ma do czynienia
        obraz_oryginalny = pygame.image.load(strumien, "name.png") 
        
        obraz_powiekszony = pygame.transform.scale(obraz_oryginalny, (256, 256))
        
        x = (400 - 256) // 2
        y = (400 - 256) // 2

        dziala = True
        while dziala:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    dziala = False
                    
            ekran.fill((50, 50, 60))
            ekran.blit(obraz_powiekszony, (x, y))
            pygame.display.flip()
            
        pygame.quit()
        sys.exit()
    except Exception as e:
        print("\n--- WYKRYTO BŁĄD ---")
        traceback.print_exc()
        input("\nNaciśnij ENTER, aby zamknąć to okno...")

if __name__ == "__main__":
    testuj_grafike()
